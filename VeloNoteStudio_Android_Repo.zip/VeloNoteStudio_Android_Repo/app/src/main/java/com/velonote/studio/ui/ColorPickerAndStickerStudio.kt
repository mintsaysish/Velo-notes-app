package com.velonote.studio.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.velonote.studio.models.ActiveToolCategory
import com.velonote.studio.models.StickerBitmapProcessor
import com.velonote.studio.models.StickerEntity
import com.velonote.studio.models.ToolSlot
import com.velonote.studio.models.colorToHex
import com.velonote.studio.models.isValidHexColor
import com.velonote.studio.models.normalizeHexColor
import com.velonote.studio.models.parseHexColor
import java.io.File
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Curated Penly-inspired minimalist stationery ink & pastel highlighter palette.
 */
private val CURATED_STATIONERY_SWATCHES = listOf(
    "#232629", "#3D5A80", "#2A6F68", "#7A4988",
    "#A24936", "#BC6C25", "#6B705C", "#E07A5F",
    "#F2CC8F", "#81B29A", "#A8DADC", "#CDB4DB"
)

/**
 * Custom Color & Tool Slot Configuration Dialog featuring:
 * - Interactive 360° HSV Color Wheel
 * - Brightness (Value) Slider
 * - Opacity Slider (5% to 100%)
 * - Stroke Width Slider (1.5pt to 48pt)
 * - Validated Hex Code Input Field (#RRGGBB) with bidirectional sync
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HsvToolColorPickerDialog(
    slot: ToolSlot,
    onDismiss: () -> Unit,
    onSaveSlot: (ToolSlot) -> Unit
) {
    val initialColor = remember(slot.colorHex) { parseHexColor(slot.colorHex) }
    val initialHsv = remember(initialColor) {
        val hsv = FloatArray(3)
        AndroidColor.colorToHSV(initialColor.toArgb(), hsv)
        hsv
    }

    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var saturation by remember { mutableFloatStateOf(initialHsv[1]) }
    var valueBrightness by remember { mutableFloatStateOf(initialHsv[2]) }
    var opacity by remember { mutableFloatStateOf(slot.opacity.coerceIn(0.1f, 1f)) }
    var strokeWidth by remember { mutableFloatStateOf(slot.strokeWidth.coerceIn(1.5f, 48f)) }

    val currentColor = remember(hue, saturation, valueBrightness) {
        Color(AndroidColor.HSVToColor(floatArrayOf(hue, saturation, valueBrightness)))
    }

    var hexInput by remember { mutableStateOf(normalizeHexColor(slot.colorHex)) }
    var hexHasError by remember { mutableStateOf(false) }

    // Keep hex text field synced when dragging the HSV color wheel
    LaunchedEffect(hue, saturation, valueBrightness) {
        val derivedHex = colorToHex(currentColor)
        if (!hexHasError) {
            hexInput = derivedHex
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFFFDFBF7),
            tonalElevation = 8.dp,
            shadowElevation = 18.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (slot.category == ActiveToolCategory.HIGHLIGHTER) {
                                "Customize Highlighter Slot"
                            } else {
                                "Customize Pen Slot"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF22252A)
                        )
                        Text(
                            text = slot.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF6E737B)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF494D54)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Live Sinusoidal Stroke Preview Box
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFF4F1EA),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .border(1.dp, Color(0xFFE2DDD3), RoundedCornerShape(16.dp))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
                        val path = Path()
                        val midY = size.height * 0.5f
                        path.moveTo(0f, midY)
                        path.cubicTo(
                            size.width * 0.3f, midY - 28f,
                            size.width * 0.7f, midY + 28f,
                            size.width, midY
                        )
                        drawPath(
                            path = path,
                            color = currentColor.copy(alpha = opacity),
                            style = Stroke(
                                width = strokeWidth,
                                cap = if (slot.category == ActiveToolCategory.HIGHLIGHTER) {
                                    StrokeCap.Square
                                } else {
                                    StrokeCap.Round
                                }
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Interactive HSV Color Wheel
                InteractiveHsvWheel(
                    hue = hue,
                    saturation = saturation,
                    valueBrightness = valueBrightness,
                    onHueSatChanged = { newHue, newSat ->
                        hue = newHue
                        saturation = newSat
                        hexHasError = false
                    },
                    modifier = Modifier.size(188.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Validated Hex Input Field (#RRGGBB) + Live Color Swatch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(currentColor.copy(alpha = opacity))
                            .border(1.dp, Color(0xFFD0C9BD), RoundedCornerShape(12.dp))
                    )

                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { typed ->
                            val clean = typed.take(7).uppercase()
                            hexInput = clean
                            if (isValidHexColor(clean)) {
                                hexHasError = false
                                val parsed = parseHexColor(clean)
                                val hsv = FloatArray(3)
                                AndroidColor.colorToHSV(parsed.toArgb(), hsv)
                                hue = hsv[0]
                                saturation = hsv[1]
                                valueBrightness = hsv[2]
                            } else {
                                hexHasError = true
                            }
                        },
                        label = { Text("Hex (#RRGGBB)") },
                        isError = hexHasError,
                        supportingText = {
                            if (hexHasError) {
                                Text("Enter a valid 6-digit hex code, e.g. #3D5A80")
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Brightness (Value) Slider
                SliderWithValueLabel(
                    title = "Brightness",
                    valueText = "${(valueBrightness * 100).toInt()}%",
                    value = valueBrightness,
                    valueRange = 0.08f..1f,
                    onValueChange = {
                        valueBrightness = it
                        hexHasError = false
                    }
                )

                // Opacity Slider
                SliderWithValueLabel(
                    title = "Opacity",
                    valueText = "${(opacity * 100).toInt()}%",
                    value = opacity,
                    valueRange = 0.10f..1f,
                    onValueChange = { opacity = it }
                )

                // Stroke Width Slider
                SliderWithValueLabel(
                    title = "Stroke Width",
                    valueText = "${"%.1f".format(strokeWidth)} pt",
                    value = strokeWidth,
                    valueRange = if (slot.category == ActiveToolCategory.HIGHLIGHTER) 12f..48f else 1.5f..24f,
                    onValueChange = { strokeWidth = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Stationery Swatches
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CURATED_STATIONERY_SWATCHES.forEach { swatchHex ->
                        val swatchColor = parseHexColor(swatchHex)
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(swatchColor)
                                .border(
                                    width = if (normalizeHexColor(hexInput) == swatchHex) 2.5.dp else 1.dp,
                                    color = if (normalizeHexColor(hexInput) == swatchHex) {
                                        Color(0xFF1F2421)
                                    } else {
                                        Color(0xFFD5CFC4)
                                    },
                                    shape = CircleShape
                                )
                                .clickable {
                                    val hsv = FloatArray(3)
                                    AndroidColor.colorToHSV(swatchColor.toArgb(), hsv)
                                    hue = hsv[0]
                                    saturation = hsv[1]
                                    valueBrightness = hsv[2]
                                    hexInput = swatchHex
                                    hexHasError = false
                                }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val finalHex = if (!hexHasError && isValidHexColor(hexInput)) {
                                normalizeHexColor(hexInput)
                            } else {
                                colorToHex(currentColor)
                            }
                            onSaveSlot(
                                slot.copy(
                                    colorHex = finalHex,
                                    opacity = opacity,
                                    strokeWidth = strokeWidth
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B3035))
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Check,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Slot")
                    }
                }
            }
        }
    }
}

@Composable
private fun InteractiveHsvWheel(
    hue: Float,
    saturation: Float,
    valueBrightness: Float,
    onHueSatChanged: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val sweepColors = remember {
        listOf(
            Color.Red,
            Color.Yellow,
            Color.Green,
            Color.Cyan,
            Color.Blue,
            Color.Magenta,
            Color.Red
        )
    }

    Canvas(
        modifier = modifier
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val center = Offset(size.width * 0.5f, size.height * 0.5f)
                    val radius = min(size.width, size.height) * 0.5f
                    val dx = offset.x - center.x
                    val dy = offset.y - center.y
                    val dist = hypot(dx, dy).coerceAtMost(radius)
                    val angleDeg = ((atan2(dy, dx) * 180.0 / PI).toFloat() + 360f) % 360f
                    onHueSatChanged(angleDeg, (dist / radius).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val offset = change.position
                    val center = Offset(size.width * 0.5f, size.height * 0.5f)
                    val radius = min(size.width, size.height) * 0.5f
                    val dx = offset.x - center.x
                    val dy = offset.y - center.y
                    val dist = hypot(dx, dy).coerceAtMost(radius)
                    val angleDeg = ((atan2(dy, dx) * 180.0 / PI).toFloat() + 360f) % 360f
                    onHueSatChanged(angleDeg, (dist / radius).coerceIn(0f, 1f))
                }
            }
    ) {
        val radius = size.minDimension * 0.5f
        val center = Offset(size.width * 0.5f, size.height * 0.5f)

        // 1. Hue Sweep Wheel
        drawCircle(
            brush = Brush.sweepGradient(colors = sweepColors, center = center),
            radius = radius,
            center = center
        )

        // 2. Radial Saturation Desaturation Overlay (White at center -> Transparent at rim)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color.Transparent),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )

        // 3. Value / Brightness Darkening Overlay
        drawCircle(
            color = Color.Black.copy(alpha = (1f - valueBrightness).coerceIn(0f, 0.92f)),
            radius = radius,
            center = center
        )

        // 4. Outer Border
        drawCircle(
            color = Color(0xFFD5CFC4),
            radius = radius,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )

        // 5. Active Thumb Indicator
        val rad = hue * (PI / 180.0).toFloat()
        val thumbDist = saturation * radius
        val thumbCenter = Offset(
            x = center.x + cos(rad) * thumbDist,
            y = center.y + sin(rad) * thumbDist
        )

        drawCircle(
            color = Color.White,
            radius = 11.dp.toPx(),
            center = thumbCenter
        )
        drawCircle(
            color = Color(AndroidColor.HSVToColor(floatArrayOf(hue, saturation, valueBrightness))),
            radius = 8.dp.toPx(),
            center = thumbCenter
        )
    }
}

@Composable
private fun SliderWithValueLabel(
    title: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF4A4E54)
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF232629)
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange
        )
    }
}

// ===========================================================================
// MODULE 4: CUSTOM STICKER STUDIO (GALLERY + LASSO + CROP + BG REMOVAL + ROOM)
// ===========================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StickerStudioBottomSheet(
    savedStickers: List<StickerEntity>,
    pendingLassoBitmap: Bitmap?,
    onClearPendingLassoBitmap: () -> Unit,
    onSaveNewSticker: (Bitmap, String, String) -> Unit,
    onPlaceStickerOnCanvas: (StickerEntity) -> Unit,
    onDeleteSavedSticker: (StickerEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Active bitmap being edited in the Sticker Studio Cropper / Background Remover
    var editingSourceBitmap by remember(pendingLassoBitmap) { mutableStateOf(pendingLassoBitmap) }
    var editingSourceType by remember(pendingLassoBitmap) {
        mutableStateOf(if (pendingLassoBitmap != null) "LASSO" else "GALLERY")
    }
    var stickerLabel by remember { mutableStateOf("Custom Sticker") }

    // Crop & Background Removal Controls
    var cropLeft by remember { mutableFloatStateOf(0.0f) }
    var cropTop by remember { mutableFloatStateOf(0.0f) }
    var cropRight by remember { mutableFloatStateOf(1.0f) }
    var cropBottom by remember { mutableFloatStateOf(1.0f) }
    var removeBgEnabled by remember { mutableStateOf(editingSourceType == "GALLERY") }
    var bgTolerance by remember { mutableFloatStateOf(0.24f) }

    val processedPreviewBitmap = remember(
        editingSourceBitmap,
        cropLeft,
        cropTop,
        cropRight,
        cropBottom,
        removeBgEnabled,
        bgTolerance
    ) {
        editingSourceBitmap?.let { src ->
            StickerBitmapProcessor.cropAndRemoveBackground(
                source = src,
                cropLeft = cropLeft,
                cropTop = cropTop,
                cropRight = cropRight,
                cropBottom = cropBottom,
                removeBackground = removeBgEnabled,
                tolerance = bgTolerance
            )
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)?.let { decoded ->
                    editingSourceBitmap = decoded
                    editingSourceType = "GALLERY"
                    cropLeft = 0f
                    cropTop = 0f
                    cropRight = 1f
                    cropBottom = 1f
                    removeBgEnabled = true
                }
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            onClearPendingLassoBitmap()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = Color(0xFFFDFBF7)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sticker Studio & Local Drawer",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF202327)
                    )
                    Text(
                        text = "Import gallery photos or lasso canvas sketches, remove backgrounds & reuse",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF6C7178)
                    )
                }

                Button(
                    onClick = { galleryLauncher.launch("image/*") },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3E5C76))
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import Photo")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // If user imported an image or lasso-captured strokes, display the Crop & BG Removal Studio
            if (processedPreviewBitmap != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF3EFE6),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFE0D9CC), RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (editingSourceType == "LASSO") {
                                    "Lasso-Captured Drawing Sticker"
                                } else {
                                    "Crop & Background Removal Studio"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            FilterChip(
                                selected = removeBgEnabled,
                                onClick = { removeBgEnabled = !removeBgEnabled },
                                label = { Text("Auto Remove BG") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.AutoFixHigh,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Checkerboard Transparency Preview Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(165.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, Color(0xFFD4CEC3), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            TransparencyCheckerboardBackground()
                            Image(
                                bitmap = processedPreviewBitmap.asImageBitmap(),
                                contentDescription = "Sticker Preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (removeBgEnabled) {
                            SliderWithValueLabel(
                                title = "Background Key Tolerance",
                                valueText = "${(bgTolerance * 100).toInt()}%",
                                value = bgTolerance,
                                valueRange = 0.04f..0.75f,
                                onValueChange = { bgTolerance = it }
                            )
                        }

                        // Horizontal & Vertical Trim Sliders
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Crop Left / Right", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cropLeft,
                                    onValueChange = { cropLeft = it.coerceAtMost(cropRight - 0.15f) },
                                    valueRange = 0f..0.75f
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Crop Top / Bottom", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cropTop,
                                    onValueChange = { cropTop = it.coerceAtMost(cropBottom - 0.15f) },
                                    valueRange = 0f..0.75f
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = stickerLabel,
                                onValueChange = { stickerLabel = it.take(28) },
                                label = { Text("Sticker Name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )

                            Button(
                                onClick = {
                                    onSaveNewSticker(
                                        processedPreviewBitmap,
                                        stickerLabel.ifBlank { "Sticker" },
                                        editingSourceType
                                    )
                                    editingSourceBitmap = null
                                    onClearPendingLassoBitmap()
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF232629))
                            ) {
                                Text("Save to Drawer")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            HorizontalDivider(color = Color(0xFFE5DFD5))
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Saved Stickers (${savedStickers.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF33373D)
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (savedStickers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFF4F1EA)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Your Sticker Drawer is empty. Use the Lasso tool on any sketch or tap 'Import Photo' above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF757A82),
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 104.dp),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.height(230.dp)
                ) {
                    items(savedStickers, key = { it.id }) { entity ->
                        StickerDrawerCard(
                            entity = entity,
                            onPlace = {
                                onPlaceStickerOnCanvas(entity)
                                onDismiss()
                            },
                            onDelete = { onDeleteSavedSticker(entity) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StickerDrawerCard(
    entity: StickerEntity,
    onPlace: () -> Unit,
    onDelete: () -> Unit
) {
    val bitmap = remember(entity.filePath) {
        val file = File(entity.filePath)
        if (file.exists()) {
            BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
        } else {
            null
        }
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF4F1EA),
        modifier = Modifier
            .size(110.dp)
            .border(1.dp, Color(0xFFE0D9CC), RoundedCornerShape(16.dp))
            .clickable { onPlace() }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = entity.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                )
            }
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.DeleteOutline,
                    contentDescription = "Delete Sticker",
                    tint = Color(0xFF9E4747),
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = entity.name,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = Color(0xFF494E54),
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 4.dp)
            )
        }
    }
}

@Composable
private fun TransparencyCheckerboardBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val tileSize = 18f
        val light = Color(0xFFFAF8F5)
        val dark = Color(0xFFE6E2DA)
        var y = 0f
        var row = 0
        while (y < size.height) {
            var x = 0f
            var col = 0
            while (x < size.width) {
                drawRect(
                    color = if ((row + col) % 2 == 0) light else dark,
                    topLeft = Offset(x, y),
                    size = Size(tileSize, tileSize)
                )
                x += tileSize
                col++
            }
            y += tileSize
            row++
        }
    }
}