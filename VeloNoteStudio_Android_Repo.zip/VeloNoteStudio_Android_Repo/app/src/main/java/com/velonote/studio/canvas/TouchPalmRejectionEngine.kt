package com.velonote.studio.canvas

import android.view.MotionEvent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import com.velonote.studio.models.DrawnStroke
import com.velonote.studio.models.StrokePoint
import com.velonote.studio.models.StudioSettings
import com.velonote.studio.models.TouchTelemetry
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Callbacks emitted by [TouchPalmRejectionEngine] to the drawing canvas controller.
 */
interface CanvasTouchListener {
    fun onStrokeBegin(canvasPoint: StrokePoint, isHardwareStylusEraser: Boolean)
    fun onStrokeMove(canvasPoints: List<StrokePoint>)
    fun onStrokeEnd()
    fun onStrokeCancel(reason: String)
    fun onCanvasPanZoom(panDeltaScreen: Offset, zoomFactor: Float, pivotScreen: Offset)
    fun onTelemetryUpdated(telemetry: TouchTelemetry)
}

/**
 * Module 1: Advanced Touch & Palm Rejection Engine
 *
 * Implements:
 * 1. Stylus Priority & Multi-Touch Filtering via MotionEvent.getToolType(pointerIndex).
 *    Prioritizes TOOL_TYPE_STYLUS & TOOL_TYPE_ERASER over concurrent finger touches.
 * 2. Wide-Touch (Palm) Rejection via event.getTouchMajor(pointerIndex) and event.getSize(pointerIndex).
 *    Immediately rejects and cancels any touch sequence whose contact area exceeds user thresholds.
 * 3. Pointer Count Limit via event.pointerCount compared against StudioSettings.maxTouchPointers,
 *    routing 1 active pointer to drawing and 2 fingers strictly to pan/zoom gestures.
 */
class TouchPalmRejectionEngine(
    private val listener: CanvasTouchListener
) {
    private val rejectedPointerIds = mutableSetOf<Int>()
    private var activeDrawingPointerId: Int = MotionEvent.INVALID_POINTER_ID
    private var activeDrawingIsStylus: Boolean = false
    private var activeDrawingStartTimeMs: Long = 0L
    private var lastStylusSeenTimeMs: Long = 0L

    // Multi-touch pan/zoom tracking state
    private var isMultiTouchGestureActive: Boolean = false
    private var previousCentroidScreen: Offset? = null
    private var previousSpanScreen: Float = 0f

    // Telemetry counters
    private var totalPalmRejections: Int = 0
    private var lastRejectionReason: String? = null

    companion object {
        private const val STYLUS_COOLDOWN_MS = 280L
        private const val MULTITOUCH_ACCIDENTAL_STROKE_WINDOW_MS = 95L
    }

    /**
     * Processes raw Android [MotionEvent] coordinates and transforms valid drawing points
     * into page-local coordinates using [screenToCanvasTransform].
     */
    fun processMotionEvent(
        event: MotionEvent,
        settings: StudioSettings,
        screenDensity: Float,
        screenToCanvasTransform: (Offset) -> Offset
    ): Boolean {
        val actionMasked = event.actionMasked
        val actionIndex = event.actionIndex
        val pointerCount = event.pointerCount
        val nowMs = event.eventTime

        // 1. Check if any pointer in the current frame is an active stylus
        var stylusPointerIndex = -1
        var isHardwareEraserTip = false
        for (i in 0 until pointerCount) {
            val toolType = event.getToolType(i)
            if (toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER) {
                stylusPointerIndex = i
                isHardwareEraserTip = (toolType == MotionEvent.TOOL_TYPE_ERASER)
                lastStylusSeenTimeMs = nowMs
                break
            }
        }

        // 2. Enforce Maximum Allowed Touch Pointers (1..5) from Settings
        if (stylusPointerIndex == -1 && pointerCount > settings.maxTouchPointers) {
            if (activeDrawingPointerId != MotionEvent.INVALID_POINTER_ID) {
                cancelActiveStroke("Pointer count ($pointerCount) exceeded max limit (${settings.maxTouchPointers})")
            }
            resetMultiTouchTracking()
            emitTelemetry(
                toolLabel = "Limit Locked ($pointerCount/${settings.maxTouchPointers})",
                pointerCount = pointerCount,
                majorPx = event.getTouchMajor(0),
                touchSize = event.getSize(0)
            )
            if (actionMasked == MotionEvent.ACTION_UP || actionMasked == MotionEvent.ACTION_CANCEL) {
                clearAllState()
            }
            return true
        }

        // 3. If a Stylus is present, immediately prioritize it and reject any concurrent finger strokes
        if (stylusPointerIndex != -1) {
            val stylusPointerId = event.getPointerId(stylusPointerIndex)
            if (isMultiTouchGestureActive) {
                resetMultiTouchTracking()
            }
            // If a finger stroke was in progress when the stylus arrived, cancel the finger stroke immediately
            if (activeDrawingPointerId != MotionEvent.INVALID_POINTER_ID && !activeDrawingIsStylus) {
                cancelActiveStroke("Stylus priority preemption")
            }

            handleStylusEvent(
                event = event,
                stylusIndex = stylusPointerIndex,
                stylusPointerId = stylusPointerId,
                isHardwareEraserTip = isHardwareEraserTip,
                screenToCanvas = screenToCanvasTransform
            )
            return true
        }

        // 4. Inspect Finger Pointers for Wide-Touch (Palm) Rejection
        val palmThresholdPx = settings.palmRejectionThresholdPx * max(1f, screenDensity * 0.45f)
        val sizeLimit = settings.palmNormalizedSizeLimit

        for (i in 0 until pointerCount) {
            val pid = event.getPointerId(i)
            val toolType = event.getToolType(i)
            if (toolType == MotionEvent.TOOL_TYPE_FINGER || toolType == MotionEvent.TOOL_TYPE_UNKNOWN) {
                val touchMajor = event.getTouchMajor(i)
                val touchSize = event.getSize(i)

                // Also inspect historical samples for sudden palm roll-on during fast movement
                var maxHistoricalMajor = touchMajor
                var maxHistoricalSize = touchSize
                for (h in 0 until event.historySize) {
                    maxHistoricalMajor = max(maxHistoricalMajor, event.getHistoricalTouchMajor(i, h))
                    maxHistoricalSize = max(maxHistoricalSize, event.getHistoricalSize(i, h))
                }

                val exceedsMajor = maxHistoricalMajor > palmThresholdPx
                val exceedsSize = maxHistoricalSize > sizeLimit
                val withinStylusCooldown = (nowMs - lastStylusSeenTimeMs) < STYLUS_COOLDOWN_MS

                if (exceedsMajor || exceedsSize || withinStylusCooldown) {
                    if (rejectedPointerIds.add(pid)) {
                        totalPalmRejections++
                        lastRejectionReason = when {
                            withinStylusCooldown -> "Stylus guard window"
                            exceedsMajor -> "Palm major (${maxHistoricalMajor.toInt()}px > ${palmThresholdPx.toInt()}px)"
                            else -> "Palm area (${"%.2f".format(maxHistoricalSize)} > ${"%.2f".format(sizeLimit)})"
                        }
                    }
                    if (activeDrawingPointerId == pid) {
                        cancelActiveStroke(lastRejectionReason ?: "Wide-touch palm rejected")
                    }
                }
            }
        }

        // Filter down to non-rejected valid pointers
        val validFingerIndices = (0 until pointerCount).filter { idx ->
            !rejectedPointerIds.contains(event.getPointerId(idx))
        }

        if (validFingerIndices.isEmpty()) {
            if (actionMasked == MotionEvent.ACTION_UP || actionMasked == MotionEvent.ACTION_CANCEL) {
                clearAllState()
            }
            emitTelemetry(
                toolLabel = "Palm Rejected",
                pointerCount = pointerCount,
                majorPx = event.getTouchMajor(0),
                touchSize = event.getSize(0)
            )
            return true
        }

        // 5. Route 2+ Valid Finger Pointers (or 1 Finger when Stylus-Only Drawing is ON) to Pan/Zoom
        if (validFingerIndices.size >= 2 || settings.stylusOnlyDrawing) {
            if (activeDrawingPointerId != MotionEvent.INVALID_POINTER_ID) {
                val elapsed = nowMs - activeDrawingStartTimeMs
                if (elapsed <= MULTITOUCH_ACCIDENTAL_STROKE_WINDOW_MS || settings.stylusOnlyDrawing) {
                    cancelActiveStroke("Switched to multi-touch pan/zoom")
                } else {
                    listener.onStrokeEnd()
                    activeDrawingPointerId = MotionEvent.INVALID_POINTER_ID
                }
            }

            handlePanZoomGesture(event, validFingerIndices, actionMasked, actionIndex)
            val firstIdx = validFingerIndices.first()
            emitTelemetry(
                toolLabel = if (settings.stylusOnlyDrawing) "Finger Pan (Stylus-Only)" else "2-Finger Pan/Zoom",
                pointerCount = validFingerIndices.size,
                majorPx = event.getTouchMajor(firstIdx),
                touchSize = event.getSize(firstIdx)
            )

            if (actionMasked == MotionEvent.ACTION_UP || actionMasked == MotionEvent.ACTION_CANCEL) {
                clearAllState()
            }
            return true
        }

        // 6. Single Valid Finger Pointer -> Drawing / Erasing / Lasso
        val primaryIndex = validFingerIndices.first()
        val primaryId = event.getPointerId(primaryIndex)

        when (actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (!isMultiTouchGestureActive && activeDrawingPointerId == MotionEvent.INVALID_POINTER_ID) {
                    activeDrawingPointerId = primaryId
                    activeDrawingIsStylus = false
                    activeDrawingStartTimeMs = nowMs
                    val canvasPt = screenToCanvasTransform(Offset(event.getX(primaryIndex), event.getY(primaryIndex)))
                    listener.onStrokeBegin(
                        StrokePoint(
                            x = canvasPt.x,
                            y = canvasPt.y,
                            pressure = event.getPressure(primaryIndex).coerceIn(0.1f, 1f),
                            timestampMs = nowMs
                        ),
                        isHardwareStylusEraser = false
                    )
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (!isMultiTouchGestureActive && activeDrawingPointerId == primaryId) {
                    val batchedPoints = extractHistoricalAndCurrentPoints(
                        event = event,
                        pointerIndex = primaryIndex,
                        screenToCanvas = screenToCanvasTransform
                    )
                    listener.onStrokeMove(batchedPoints)
                }
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val liftedId = event.getPointerId(actionIndex)
                rejectedPointerIds.remove(liftedId)
                if (liftedId == activeDrawingPointerId) {
                    listener.onStrokeEnd()
                    activeDrawingPointerId = MotionEvent.INVALID_POINTER_ID
                }
            }

            MotionEvent.ACTION_UP -> {
                if (activeDrawingPointerId == primaryId) {
                    listener.onStrokeEnd()
                }
                clearAllState()
            }

            MotionEvent.ACTION_CANCEL -> {
                if (activeDrawingPointerId != MotionEvent.INVALID_POINTER_ID) {
                    cancelActiveStroke("System touch canceled")
                }
                clearAllState()
            }
        }

        emitTelemetry(
            toolLabel = "Finger Draw",
            pointerCount = validFingerIndices.size,
            majorPx = event.getTouchMajor(primaryIndex),
            touchSize = event.getSize(primaryIndex)
        )
        return true
    }

    private fun handleStylusEvent(
        event: MotionEvent,
        stylusIndex: Int,
        stylusPointerId: Int,
        isHardwareEraserTip: Boolean,
        screenToCanvas: (Offset) -> Offset
    ) {
        val actionMasked = event.actionMasked
        val nowMs = event.eventTime

        when (actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.actionIndex == stylusIndex || activeDrawingPointerId == MotionEvent.INVALID_POINTER_ID) {
                    activeDrawingPointerId = stylusPointerId
                    activeDrawingIsStylus = true
                    activeDrawingStartTimeMs = nowMs
                    val canvasPt = screenToCanvas(Offset(event.getX(stylusIndex), event.getY(stylusIndex)))
                    listener.onStrokeBegin(
                        StrokePoint(
                            x = canvasPt.x,
                            y = canvasPt.y,
                            pressure = event.getPressure(stylusIndex).coerceIn(0.05f, 1f),
                            timestampMs = nowMs
                        ),
                        isHardwareStylusEraser = isHardwareEraserTip
                    )
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (activeDrawingPointerId == stylusPointerId) {
                    val points = extractHistoricalAndCurrentPoints(event, stylusIndex, screenToCanvas)
                    listener.onStrokeMove(points)
                }
            }

            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> {
                if (actionMasked == MotionEvent.ACTION_UP || event.getPointerId(event.actionIndex) == stylusPointerId) {
                    if (activeDrawingPointerId == stylusPointerId) {
                        listener.onStrokeEnd()
                    }
                    activeDrawingPointerId = MotionEvent.INVALID_POINTER_ID
                    activeDrawingIsStylus = false
                }
                if (actionMasked == MotionEvent.ACTION_UP) {
                    clearAllState()
                }
            }

            MotionEvent.ACTION_CANCEL -> {
                cancelActiveStroke("Stylus event canceled")
                clearAllState()
            }
        }

        emitTelemetry(
            toolLabel = if (isHardwareEraserTip) "Stylus Tail Eraser" else "Active Stylus",
            pointerCount = event.pointerCount,
            majorPx = event.getTouchMajor(stylusIndex),
            touchSize = event.getSize(stylusIndex)
        )
    }

    private fun handlePanZoomGesture(
        event: MotionEvent,
        validIndices: List<Int>,
        actionMasked: Int,
        actionIndex: Int
    ) {
        isMultiTouchGestureActive = true

        // Exclude a pointer that is currently lifting on ACTION_POINTER_UP
        val activeIndices = if (actionMasked == MotionEvent.ACTION_POINTER_UP) {
            validIndices.filter { it != actionIndex }
        } else {
            validIndices
        }

        if (activeIndices.isEmpty()) {
            resetMultiTouchTracking()
            return
        }

        var sumX = 0f
        var sumY = 0f
        for (idx in activeIndices) {
            sumX += event.getX(idx)
            sumY += event.getY(idx)
        }
        val centroid = Offset(sumX / activeIndices.size, sumY / activeIndices.size)

        var span = 0f
        if (activeIndices.size >= 2) {
            var distSum = 0f
            for (idx in activeIndices) {
                distSum += hypot(event.getX(idx) - centroid.x, event.getY(idx) - centroid.y)
            }
            span = distSum / activeIndices.size
        }

        if (actionMasked == MotionEvent.ACTION_MOVE && previousCentroidScreen != null) {
            val panDelta = centroid - previousCentroidScreen!!
            val zoomFactor = if (activeIndices.size >= 2 && previousSpanScreen > 12f && span > 12f) {
                (span / previousSpanScreen).coerceIn(0.85f, 1.18f)
            } else {
                1f
            }
            listener.onCanvasPanZoom(panDelta, zoomFactor, centroid)
        }

        previousCentroidScreen = centroid
        previousSpanScreen = span
    }

    private fun extractHistoricalAndCurrentPoints(
        event: MotionEvent,
        pointerIndex: Int,
        screenToCanvas: (Offset) -> Offset
    ): List<StrokePoint> {
        val historySize = event.historySize
        val result = ArrayList<StrokePoint>(historySize + 1)
        for (h in 0 until historySize) {
            val hx = event.getHistoricalX(pointerIndex, h)
            val hy = event.getHistoricalY(pointerIndex, h)
            val hp = event.getHistoricalPressure(pointerIndex, h).coerceIn(0.05f, 1f)
            val hTime = event.getHistoricalEventTime(h)
            val mapped = screenToCanvas(Offset(hx, hy))
            result.add(StrokePoint(mapped.x, mapped.y, hp, hTime))
        }
        val currentMapped = screenToCanvas(Offset(event.getX(pointerIndex), event.getY(pointerIndex)))
        result.add(
            StrokePoint(
                x = currentMapped.x,
                y = currentMapped.y,
                pressure = event.getPressure(pointerIndex).coerceIn(0.05f, 1f),
                timestampMs = event.eventTime
            )
        )
        return result
    }

    private fun cancelActiveStroke(reason: String) {
        activeDrawingPointerId = MotionEvent.INVALID_POINTER_ID
        activeDrawingIsStylus = false
        listener.onStrokeCancel(reason)
    }

    private fun resetMultiTouchTracking() {
        isMultiTouchGestureActive = false
        previousCentroidScreen = null
        previousSpanScreen = 0f
    }

    private fun clearAllState() {
        rejectedPointerIds.clear()
        activeDrawingPointerId = MotionEvent.INVALID_POINTER_ID
        activeDrawingIsStylus = false
        resetMultiTouchTracking()
    }

    private fun emitTelemetry(
        toolLabel: String,
        pointerCount: Int,
        majorPx: Float,
        touchSize: Float
    ) {
        listener.onTelemetryUpdated(
            TouchTelemetry(
                activeToolTypeLabel = toolLabel,
                activePointers = pointerCount,
                lastTouchMajorPx = majorPx,
                lastTouchSize = touchSize,
                palmRejectedCount = totalPalmRejections,
                lastRejectionReason = lastRejectionReason
            )
        )
    }
}

// ===========================================================================
// MODULE 2: STROKE SMOOTHING (CATMULL-ROM + QUADRATIC BEZIER) & SPATIAL MATH
// ===========================================================================

object StrokeSmoothingAndGeometry {

    /**
     * Applies adaptive jitter filtering + Catmull-Rom spline interpolation controlled by
     * [smoothingIntensity] in [0f..1f], preparing vertices for Quadratic Bézier rendering.
     */
    fun computeSmoothedPoints(
        rawPoints: List<StrokePoint>,
        smoothingIntensity: Float
    ): List<Offset> {
        if (rawPoints.isEmpty()) return emptyList()
        if (rawPoints.size == 1) {
            return listOf(Offset(rawPoints[0].x, rawPoints[0].y))
        }

        val clampedIntensity = smoothingIntensity.coerceIn(0f, 1f)
        val minDistancePx = 1.2f + clampedIntensity * 2.8f

        // Step 1: Decimate micro-jitter and apply low-latency exponential smoothing
        val filtered = ArrayList<Offset>(rawPoints.size)
        var lastAccepted = Offset(rawPoints[0].x, rawPoints[0].y)
        filtered.add(lastAccepted)

        val alpha = (1f - clampedIntensity * 0.58f).coerceIn(0.32f, 1f)
        for (i in 1 until rawPoints.size) {
            val candidate = Offset(rawPoints[i].x, rawPoints[i].y)
            val dist = hypot(candidate.x - lastAccepted.x, candidate.y - lastAccepted.y)
            if (dist >= minDistancePx || i == rawPoints.lastIndex) {
                val smoothed = Offset(
                    x = lastAccepted.x + (candidate.x - lastAccepted.x) * alpha,
                    y = lastAccepted.y + (candidate.y - lastAccepted.y) * alpha
                )
                filtered.add(smoothed)
                lastAccepted = smoothed
            }
        }

        if (filtered.size < 4 || clampedIntensity <= 0.05f) {
            return filtered
        }

        // Step 2: Subdivide with Catmull-Rom Spline interpolation for silky curves
        val subdivisions = if (clampedIntensity > 0.6f) 3 else 2
        val splineOutput = ArrayList<Offset>(filtered.size * subdivisions)
        splineOutput.add(filtered.first())

        for (i in 0 until filtered.size - 1) {
            val p0 = if (i == 0) filtered[0] else filtered[i - 1]
            val p1 = filtered[i]
            val p2 = filtered[i + 1]
            val p3 = if (i + 2 < filtered.size) filtered[i + 2] else filtered[i + 1]

            for (step in 1..subdivisions) {
                val t = step.toFloat() / subdivisions.toFloat()
                splineOutput.add(evalCatmullRom(p0, p1, p2, p3, t, tension = 0.5f))
            }
        }

        return splineOutput
    }

    /**
     * Standard Catmull-Rom spline evaluation between [p1] and [p2] at parameter [t] in [0..1].
     */
    private fun evalCatmullRom(
        p0: Offset,
        p1: Offset,
        p2: Offset,
        p3: Offset,
        t: Float,
        tension: Float = 0.5f
    ): Offset {
        val t2 = t * t
        val t3 = t2 * t

        val m1x = tension * (p2.x - p0.x)
        val m1y = tension * (p2.y - p0.y)
        val m2x = tension * (p3.x - p1.x)
        val m2y = tension * (p3.y - p1.y)

        val h00 = 2f * t3 - 3f * t2 + 1f
        val h10 = t3 - 2f * t2 + t
        val h01 = -2f * t3 + 3f * t2
        val h11 = t3 - t2

        return Offset(
            x = h00 * p1.x + h10 * m1x + h01 * p2.x + h11 * m2x,
            y = h00 * p1.y + h10 * m1y + h01 * p2.y + h11 * m2y
        )
    }

    /**
     * Builds a smooth Compose [Path] using Quadratic Bézier midpoint interpolation (`Path.quadTo`).
     */
    fun buildQuadraticBezierPath(points: List<Offset>): Path {
        val path = Path()
        if (points.isEmpty()) return path

        val first = points.first()
        path.moveTo(first.x, first.y)

        if (points.size == 1) {
            path.lineTo(first.x + 0.4f, first.y + 0.4f)
            return path
        }

        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val curr = points[i]
            val midX = (prev.x + curr.x) * 0.5f
            val midY = (prev.y + curr.y) * 0.5f
            path.quadTo(prev.x, prev.y, midX, midY)
        }

        val last = points.last()
        path.lineTo(last.x, last.y)
        return path
    }

    /**
     * Computes axis-aligned bounding box for fast spatial indexing and Stroke Eraser broad-phase rejection.
     */
    fun computeBoundingBox(points: List<Offset>, strokeWidth: Float): Rect {
        if (points.isEmpty()) return Rect.Zero
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE

        for (pt in points) {
            minX = min(minX, pt.x)
            minY = min(minY, pt.y)
            maxX = max(maxX, pt.x)
            maxY = max(maxY, pt.y)
        }
        val pad = strokeWidth * 0.6f + 2f
        return Rect(minX - pad, minY - pad, maxX + pad, maxY + pad)
    }

    /**
     * Vector Stroke Eraser hit-test: checks if an eraser circle at [eraserCenter] with [eraserRadius]
     * intersects any polyline segment of [stroke].
     */
    fun doesEraserIntersectStroke(
        eraserCenter: Offset,
        eraserRadius: Float,
        stroke: DrawnStroke
    ): Boolean {
        if (stroke.isPixelEraserMask || stroke.smoothedPoints.isEmpty()) return false

        val combinedRadius = eraserRadius + stroke.strokeWidth * 0.5f
        val expandedBounds = stroke.boundingBox.inflate(eraserRadius)
        if (!expandedBounds.contains(eraserCenter)) {
            return false
        }

        val thresholdSq = combinedRadius * combinedRadius
        val pts = stroke.smoothedPoints
        if (pts.size == 1) {
            val dx = eraserCenter.x - pts[0].x
            val dy = eraserCenter.y - pts[0].y
            return (dx * dx + dy * dy) <= thresholdSq
        }

        for (i in 0 until pts.size - 1) {
            val distSq = pointToSegmentDistanceSquared(eraserCenter, pts[i], pts[i + 1])
            if (distSq <= thresholdSq) {
                return true
            }
        }
        return false
    }

    private fun pointToSegmentDistanceSquared(p: Offset, a: Offset, b: Offset): Float {
        val abx = b.x - a.x
        val aby = b.y - a.y
        val lenSq = abx * abx + aby * aby
        if (lenSq <= 1e-5f) {
            val dx = p.x - a.x
            val dy = p.y - a.y
            return dx * dx + dy * dy
        }
        val t = (((p.x - a.x) * abx + (p.y - a.y) * aby) / lenSq).coerceIn(0f, 1f)
        val projX = a.x + t * abx
        val projY = a.y + t * aby
        val dx = p.x - projX
        val dy = p.y - projY
        return dx * dx + dy * dy
    }

    /**
     * Ray-casting point-in-polygon test used by the Lasso tool to capture canvas drawings into Stickers.
     */
    fun isStrokeSelectedByLasso(stroke: DrawnStroke, lassoPolygon: List<Offset>): Boolean {
        if (stroke.isPixelEraserMask || lassoPolygon.size < 3 || stroke.smoothedPoints.isEmpty()) {
            return false
        }
        // Select stroke if at least 35% of its sampled vertices fall inside the freehand lasso loop
        val pts = stroke.smoothedPoints
        val step = max(1, pts.size / 12)
        var tested = 0
        var insideCount = 0
        for (i in pts.indices step step) {
            tested++
            if (isPointInPolygon(pts[i], lassoPolygon)) {
                insideCount++
            }
        }
        return tested > 0 && (insideCount.toFloat() / tested.toFloat()) >= 0.35f
    }

    private fun isPointInPolygon(point: Offset, polygon: List<Offset>): Boolean {
        var inside = false
        var j = polygon.lastIndex
        for (i in polygon.indices) {
            val pi = polygon[i]
            val pj = polygon[j]
            val intersects = ((pi.y > point.y) != (pj.y > point.y)) &&
                (point.x < (pj.x - pi.x) * (point.y - pi.y) / ((pj.y - pi.y).takeIf { abs(it) > 1e-5f } ?: 1e-5f) + pi.x)
            if (intersects) {
                inside = !inside
            }
            j = i
        }
        return inside
    }
}