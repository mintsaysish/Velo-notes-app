package com.velonote.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.velonote.studio.models.VeloStudioDatabase
import com.velonote.studio.ui.VeloNoteStudioScreen

private val VeloChicColorScheme = lightColorScheme(
    primary = Color(0xFF2B3035),
    onPrimary = Color(0xFFFDFBF7),
    secondary = Color(0xFF4A6FA5),
    onSecondary = Color.White,
    background = Color(0xFFEDEAE4),
    surface = Color(0xFFFDFBF7),
    onSurface = Color(0xFF202327)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = VeloStudioDatabase.getInstance(applicationContext)
        val stickerDao = database.stickerDao()

        setContent {
            MaterialTheme(colorScheme = VeloChicColorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VeloNoteStudioScreen(stickerDao = stickerDao)
                }
            }
        }
    }
}