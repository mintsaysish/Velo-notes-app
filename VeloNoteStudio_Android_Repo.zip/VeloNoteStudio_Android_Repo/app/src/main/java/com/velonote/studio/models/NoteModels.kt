package com.velonote.studio.models

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Primary tool modes supported by the floating studio dock.
 */
enum class ActiveToolCategory {
    PEN,
    HIGHLIGHTER,
    ERASER,
    LASSO,
    PAN_ZOOM
}

/**
 * Dual eraser modes:
 * - STROKE: Vector spatial intersection that deletes an entire continuous stroke on contact.
 * - PIXEL: Raster/path masking using BlendMode.Clear with adjustable radius.
 */
enum class EraserMode(val title: String, val subtitle: String) {
    STROKE("Stroke Eraser", "Deletes entire continuous vector stroke on contact"),
    PIXEL("Pixel Eraser", "Masks ink & highlighter paths with BlendMode.Clear")
}

/**
 * Dynamic page templates rendered procedurally on the background canvas.
 */
enum class PageTemplate(val displayName: String) {
    BLANK("Blank Paper"),
    LINED_NARROW("Narrow Ruled"),
    LINED_WIDE("Wide Ruled"),
    GRID_SQUARE("Square Grid"),
    GRID_ISOMETRIC("Isometric Grid"),
    DOTTED("Bullet Dotted")
}

/**
 * Standardized planner & note-taking aspect ratios.
 */
enum class PageAspectRatio(
    val displayName: String,
    val badge: String,
    val widthPx: Float,
    val heightPx: Float
) {
    A4("A4 Standard", "1:√2", 1414f, 2000f),
    A5("A5 Planner", "A5", 1050f, 1485f),
    US_LETTER("US Letter", "8.5×11", 1545f, 2000f),
    WIDESCREEN_16_9("16:9 Widescreen", "16:9", 2240f, 1260f),
    TABLET_4_3("4:3 Tablet", "4:3", 2000f, 1500f),
    SQUARE("Square Journal", "1:1", 1600f, 1600f)
}

/**
 * Left-handed vs. Right-handed dock orientation.
 */
enum class ToolbarHandedness(val label: String) {
    RIGHT_HANDED("Right-Handed"),
    LEFT_HANDED("Left-Handed")
}

/**
 * Distraction-free canvas surface themes.
 */
enum class CanvasThemeMode(
    val label: String,
    val paperBgHex: Long,
    val workspaceBgHex: Long,
    val lineColorHex: Long
) {
    WARM_LIGHT(
        label = "Warm Ivory",
        paperBgHex = 0xFFFBF9F5,
        workspaceBgHex = 0xFFEDEAE4,
        lineColorHex = 0xFFD8D2C7
    ),
    OBSIDIAN_DARK(
        label = "Obsidian Slate",
        paperBgHex = 0xFF1E2024,
        workspaceBgHex = 0xFF121316,
        lineColorHex = 0xFF353840
    )
}

/**
 * Saved Pen or Highlighter preset slot in the floating toolbar dock.
 */
data class ToolSlot(
    val id: String = UUID.randomUUID().toString(),
    val category: ActiveToolCategory,
    val label: String,
    val colorHex: String,
    val strokeWidth: Float,
    val opacity: Float
) {
    val composeColor: Color
        get() = parseHexColor(colorHex).copy(alpha = opacity.coerceIn(0.05f, 1.0f))
}

/**
 * Raw digitizer sample captured from MotionEvent (including historical batched samples).
 */
data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 1.0f,
    val timestampMs: Long = System.currentTimeMillis()
)

/**
 * Immutable vector stroke stored on the page canvas.
 * Supports opaque Pen ink, multiply/darken Highlighter ink, and BlendMode.Clear Pixel Eraser masks.
 */
data class DrawnStroke(
    val id: String = UUID.randomUUID().toString(),
    val rawPoints: List<StrokePoint>,
    val smoothedPoints: List<Offset>,
    val colorHex: String,
    val opacity: Float,
    val strokeWidth: Float,
    val isHighlighter: Boolean = false,
    val isPixelEraserMask: Boolean = false,
    val boundingBox: Rect
) {
    val renderColor: Color
        get() = parseHexColor(colorHex).copy(alpha = opacity.coerceIn(0.05f, 1f))
}

/**
 * Active sticker instance placed onto the planner canvas with full 2D transform handles.
 */
data class PlacedSticker(
    val instanceId: String = UUID.randomUUID().toString(),
    val stickerEntityId: Long,
    val filePath: String,
    val centerX: Float,
    val centerY: Float,
    val width: Float = 260f,
    val height: Float = 260f,
    val rotationDegrees: Float = 0f
)

/**
 * User-configurable studio & palm-rejection settings controlled via SettingsSheet.
 */
data class StudioSettings(
    val palmRejectionThresholdPx: Float = 30f,
    val palmNormalizedSizeLimit: Float = 0.22f,
    val maxTouchPointers: Int = 2,
    val stylusOnlyDrawing: Boolean = false,
    val smoothingIntensity: Float = 0.65f,
    val handedness: ToolbarHandedness = ToolbarHandedness.RIGHT_HANDED,
    val pageTemplate: PageTemplate = PageTemplate.DOTTED,
    val aspectRatio: PageAspectRatio = PageAspectRatio.A4,
    val canvasTheme: CanvasThemeMode = CanvasThemeMode.WARM_LIGHT
)

/**
 * Telemetry snapshot from the Touch & Palm Rejection Engine for subtle UI status feedback.
 */
data class TouchTelemetry(
    val activeToolTypeLabel: String = "Idle",
    val activePointers: Int = 0,
    val lastTouchMajorPx: Float = 0f,
    val lastTouchSize: Float = 0f,
    val palmRejectedCount: Int = 0,
    val lastRejectionReason: String? = null
)

// ===========================================================================
// ROOM DATABASE FOR CUSTOM STICKER STUDIO
// ===========================================================================

@Entity(tableName = "stickers")
data class StickerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val filePath: String,
    val sourceType: String, // "GALLERY" or "LASSO"
    val createdAtMs: Long = System.currentTimeMillis()
)

@Dao
interface StickerDao {
    @Query("SELECT * FROM stickers ORDER BY createdAtMs DESC")
    fun observeAllStickers(): Flow<List<StickerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSticker(sticker: StickerEntity): Long

    @Delete
    suspend fun deleteSticker(sticker: StickerEntity)
}

@Database(entities = [StickerEntity::class], version = 1, exportSchema = false)
abstract class VeloStudioDatabase : RoomDatabase() {
    abstract fun stickerDao(): StickerDao

    companion object {
        @Volatile
        private var INSTANCE: VeloStudioDatabase? = null

        fun getInstance(context: Context): VeloStudioDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VeloStudioDatabase::class.java,
                    "velo_note_studio.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// ===========================================================================
// STICKER BITMAP CROPPING, BACKGROUND REMOVAL & LASSO RASTERIZER
// ===========================================================================

object StickerBitmapProcessor {

    /**
     * Crops a source Bitmap using normalized crop bounds [0f..1f] and optionally removes
     * solid/paper background pixels using corner-sampled color distance with soft alpha feathering.
     */
    fun cropAndRemoveBackground(
        source: Bitmap,
        cropLeft: Float,
        cropTop: Float,
        cropRight: Float,
        cropBottom: Float,
        removeBackground: Boolean,
        tolerance: Float
    ): Bitmap {
        val safeLeft = (cropLeft.coerceIn(0f, 0.9f) * source.width).toInt()
        val safeTop = (cropTop.coerceIn(0f, 0.9f) * source.height).toInt()
        val safeRight = (cropRight.coerceIn(cropLeft + 0.1f, 1f) * source.width).toInt()
        val safeBottom = (cropBottom.coerceIn(cropTop + 0.1f, 1f) * source.height).toInt()

        val cropW = max(16, safeRight - safeLeft)
        val safeW = min(cropW, source.width - safeLeft)
        val cropH = max(16, safeBottom - safeTop)
        val safeH = min(cropH, source.height - safeTop)

        val cropped = Bitmap.createBitmap(source, safeLeft, safeTop, safeW, safeH)
        if (!removeBackground || tolerance <= 0.01f) {
            return cropped.copy(Bitmap.Config.ARGB_8888, true)
        }

        val mutable = cropped.copy(Bitmap.Config.ARGB_8888, true)
        val w = mutable.width
        val h = mutable.height
        val pixels = IntArray(w * h)
        mutable.getPixels(pixels, 0, w, 0, 0, w, h)

        // Sample corner pixels to estimate background reference color (defaults to paper white if transparent)
        val cornerSamples = listOf(
            pixels[0],
            pixels[w - 1],
            pixels[(h - 1) * w],
            pixels[(h - 1) * w + (w - 1)]
        ).filter { AndroidColor.alpha(it) > 32 }

        val bgR: Int
        val bgG: Int
        val bgB: Int
        if (cornerSamples.isNotEmpty()) {
            bgR = cornerSamples.map { AndroidColor.red(it) }.average().toInt()
            bgG = cornerSamples.map { AndroidColor.green(it) }.average().toInt()
            bgB = cornerSamples.map { AndroidColor.blue(it) }.average().toInt()
        } else {
            bgR = 250
            bgG = 248
            bgB = 244
        }

        // Maximum Euclidean RGB distance is sqrt(255^2 * 3) ≈ 441.67
        val maxThreshold = tolerance.coerceIn(0.02f, 0.95f) * 260f
        val featherBand = max(12f, maxThreshold * 0.25f)

        for (i in pixels.indices) {
            val px = pixels[i]
            val a = AndroidColor.alpha(px)
            if (a == 0) continue

            val r = AndroidColor.red(px)
            val g = AndroidColor.green(px)
            val b = AndroidColor.blue(px)

            val dr = (r - bgR).toFloat()
            val dg = (g - bgG).toFloat()
            val db = (b - bgB).toFloat()
            val dist = sqrt(dr * dr + dg * dg + db * db)

            if (dist <= maxThreshold - featherBand) {
                pixels[i] = AndroidColor.argb(0, r, g, b)
            } else if (dist < maxThreshold) {
                val factor = ((dist - (maxThreshold - featherBand)) / featherBand).coerceIn(0f, 1f)
                val newAlpha = (a * factor).toInt().coerceIn(0, 255)
                pixels[i] = AndroidColor.argb(newAlpha, r, g, b)
            }
        }

        mutable.setPixels(pixels, 0, w, 0, 0, w, h)
        return mutable
    }

    /**
     * Rasterizes canvas strokes captured by the freehand Lasso tool into a crisp transparent Bitmap
     * ready for the Sticker Studio cropper & persistent Room drawer.
     */
    fun rasterizeLassoStrokesToBitmap(
        strokes: List<DrawnStroke>,
        paddingPx: Float = 28f
    ): Bitmap? {
        val visibleStrokes = strokes.filter { !it.isPixelEraserMask && it.smoothedPoints.isNotEmpty() }
        if (visibleStrokes.isEmpty()) return null

        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var maxY = Float.MIN_VALUE

        for (stroke in visibleStrokes) {
            val halfW = stroke.strokeWidth * 0.6f
            minX = min(minX, stroke.boundingBox.left - halfW)
            minY = min(minY, stroke.boundingBox.top - halfW)
            maxX = max(maxX, stroke.boundingBox.right + halfW)
            maxY = max(maxY, stroke.boundingBox.bottom + halfW)
        }

        val width = (maxX - minX + paddingPx * 2f).toInt().coerceIn(64, 2048)
        val height = (maxY - minY + paddingPx * 2f).toInt().coerceIn(64, 2048)

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bitmap)

        // Draw highlighters first, then ink strokes
        val ordered = visibleStrokes.sortedBy { if (it.isHighlighter) 0 else 1 }
        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
            style = AndroidPaint.Style.STROKE
            strokeCap = AndroidPaint.Cap.ROUND
            strokeJoin = AndroidPaint.Join.ROUND
        }

        for (stroke in ordered) {
            paint.color = stroke.renderColor.toArgb()
            paint.strokeWidth = stroke.strokeWidth
            val pts = stroke.smoothedPoints
            val path = AndroidPath()
            val startX = pts.first().x - minX + paddingPx
            val startY = pts.first().y - minY + paddingPx
            path.moveTo(startX, startY)

            if (pts.size == 1) {
                path.lineTo(startX + 0.5f, startY + 0.5f)
            } else {
                for (i in 1 until pts.size) {
                    val prev = pts[i - 1]
                    val curr = pts[i]
                    val prevX = prev.x - minX + paddingPx
                    val prevY = prev.y - minY + paddingPx
                    val currX = curr.x - minX + paddingPx
                    val currY = curr.y - minY + paddingPx
                    val midX = (prevX + currX) * 0.5f
                    val midY = (prevY + currY) * 0.5f
                    path.quadTo(prevX, prevY, midX, midY)
                }
                val last = pts.last()
                path.lineTo(last.x - minX + paddingPx, last.y - minY + paddingPx)
            }
            canvas.drawPath(path, paint)
        }

        return bitmap
    }

    /**
     * Persists a processed Sticker Bitmap as a lossless PNG in app-private internal storage.
     */
    fun saveBitmapToStickerStorage(context: Context, bitmap: Bitmap): File {
        val stickerDir = File(context.filesDir, "stickers")
        if (!stickerDir.exists()) {
            stickerDir.mkdirs()
        }
        val file = File(stickerDir, "sticker_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
        }
        return file
    }
}

/**
 * Helper utilities for validated #RRGGBB hex parsing and formatting.
 */
fun isValidHexColor(input: String): Boolean {
    val regex = Regex("^#?[0-9A-Fa-f]{6}$")
    return regex.matches(input.trim())
}

fun normalizeHexColor(input: String): String {
    val clean = input.trim().removePrefix("#").uppercase()
    return if (clean.length == 6 && clean.all { it in '0'..'9' || it in 'A'..'F' }) {
        "#$clean"
    } else {
        "#2C302E"
    }
}

fun parseHexColor(hexString: String): Color {
    val normalized = normalizeHexColor(hexString)
    return try {
        Color(AndroidColor.parseColor(normalized))
    } catch (e: Exception) {
        Color(0xFF2C302E)
    }
}

fun colorToHex(color: Color): String {
    val argb = color.toArgb()
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    return String.format("#%02X%02X%02X", r, g, b)
}