package com.velonote.studio.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.velonote.studio.models.CanvasThemeMode
import com.velonote.studio.models.PageAspectRatio
import com.velonote.studio.models.PageTemplate
import com.velonote.studio.models.StudioSettings
import com.velonote.studio.models.ToolbarHandedness
import com.velonote.studio.models.TouchTelemetry
import kotlin.math.roundToInt

/**
 * Module 5: Dedicated Comprehensive Studio Settings Sheet
 *
 * Controls:
 * 1. Palm rejection contact-size threshold slider (touchMajor px & normalized contact area)
 * 2. Maximum allowed touch pointers (1 to 5)
 * 3. Stylus-only drawing toggle (fingers strictly pan/zoom)
 * 4. Handwriting smoothing intensity slider (0% to 100%)
 * 5. Left-handed vs. Right-handed toolbar orientation
 * 6. Default page template, aspect ratio & dark/light canvas theme
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StudioSettingsBottomSheet(
    settings: StudioSettings,
    telemetry: TouchTelemetry,
    onUpdateSettings: (StudioSettings) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFFFDFBF7)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                text = "Studio & Touch Engine Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2327)
            )
            Text(
                text = "Fine-tune palm rejection thresholds, stylus priority, spline smoothing & page geometry",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF6B7078)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Live Touch & Palm Rejection Telemetry Strip
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFF3EFE6),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFE0D9CC), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "LIVE DIGITIZER TELEMETRY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF5A626A)
                    )
                    Text(
                        text = "Input: ${telemetry.activeToolTypeLabel}  •  Pointers: ${telemetry.activePointers}  •  Rejected Palms: ${telemetry.palmRejectedCount}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF232629)
                    )
                    Text(
                        text = "Last Contact Major: ${"%.1f".format(telemetry.lastTouchMajorPx)}px  •  Normalized Size: ${"%.2f".format(telemetry.lastTouchSize)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF4F555C)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 1. Stylus-Only Drawing Mode Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(
                        text = "Stylus-Only Drawing",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF22252A)
                    )
                    Text(
                        text = "Only TOOL_TYPE_STYLUS draws ink; finger touches strictly pan & zoom the canvas",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF6B7078)
                    )
                }
                Switch(
                    checked = settings.stylusOnlyDrawing,
                    onCheckedChange = { onUpdateSettings(settings.copy(stylusOnlyDrawing = it)) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Wide-Touch (Palm) Rejection Contact-Size Threshold Slider
            SettingSliderSection(
                title = "Palm Rejection Contact Threshold",
                subtitle = "Cancels any touch sequence whose getTouchMajor() or getSize() exceeds threshold",
                badgeText = "${settings.palmRejectionThresholdPx.roundToInt()} px / ${"%.2f".format(settings.palmNormalizedSizeLimit)}",
                value = settings.palmRejectionThresholdPx,
                valueRange = 12f..64f,
                onValueChange = { newMajorPx ->
                    // Scale normalized size threshold proportionally [0.08 .. 0.42]
                    val normalizedSize = (0.08f + ((newMajorPx - 12f) / 52f) * 0.34f).coerceIn(0.08f, 0.45f)
                    onUpdateSettings(
                        settings.copy(
                            palmRejectionThresholdPx = newMajorPx,
                            palmNormalizedSizeLimit = normalizedSize
                        )
                    )
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Maximum Allowed Simultaneous Touch Pointers (1 to 5)
            Text(
                text = "Maximum Allowed Touch Pointers (1 to 5)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Text(
                text = "Locks event.pointerCount ceiling (e.g., 1 for drawing only, 2 for 1-finger draw + 2-finger pan/zoom)",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF6B7078)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { count ->
                    FilterChip(
                        selected = (settings.maxTouchPointers == count),
                        onClick = { onUpdateSettings(settings.copy(maxTouchPointers = count)) },
                        label = { Text("$count ${if (count == 1) "Ptr" else "Ptrs"}") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Handwriting Smoothing Intensity Slider (0% to 100%)
            SettingSliderSection(
                title = "Handwriting Smoothing Intensity",
                subtitle = "Controls Catmull-Rom spline subdivision & Quadratic Bézier (Path.quadTo) damping",
                badgeText = "${(settings.smoothingIntensity * 100).roundToInt()}%",
                value = settings.smoothingIntensity,
                valueRange = 0f..1f,
                onValueChange = { onUpdateSettings(settings.copy(smoothingIntensity = it)) }
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color(0xFFE5DFD5))
            Spacer(modifier = Modifier.height(16.dp))

            // 5. Left-Handed vs. Right-Handed Toolbar Orientation
            Text(
                text = "Workspace Handedness & Dock Orientation",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ToolbarHandedness.entries.forEach { mode ->
                    FilterChip(
                        selected = (settings.handedness == mode),
                        onClick = { onUpdateSettings(settings.copy(handedness = mode)) },
                        label = { Text(mode.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 6. Canvas Surface Theme (Warm Ivory Light vs. Obsidian Dark)
            Text(
                text = "Canvas Paper & Workspace Theme",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CanvasThemeMode.entries.forEach { theme ->
                    FilterChip(
                        selected = (settings.canvasTheme == theme),
                        onClick = { onUpdateSettings(settings.copy(canvasTheme = theme)) },
                        label = { Text(theme.label) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 7. Page Template Picker
            Text(
                text = "Page Template Pattern",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PageTemplate.entries.forEach { template ->
                    FilterChip(
                        selected = (settings.pageTemplate == template),
                        onClick = { onUpdateSettings(settings.copy(pageTemplate = template)) },
                        label = { Text(template.displayName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 8. Standardized Page Aspect Ratio Picker
            Text(
                text = "Standardized Page Aspect Ratio",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PageAspectRatio.entries.forEach { ratio ->
                    FilterChip(
                        selected = (settings.aspectRatio == ratio),
                        onClick = { onUpdateSettings(settings.copy(aspectRatio = ratio)) },
                        label = { Text("${ratio.displayName} (${ratio.badge})") }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSliderSection(
    title: String,
    subtitle: String,
    badgeText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF22252A)
            )
            Text(
                text = badgeText,
                style = MaterialTheme.typography.labelMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF3E5C76),
                modifier = Modifier
                    .background(Color(0xFFEBE6DC), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF6B7078)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange
        )
    }
}