package com.velonote.studio.canvas

import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.velonote.studio.models.ActiveToolCategory
import com.velonote.studio.models.CanvasThemeMode
import com.velonote.studio.models.DrawnStroke
import com.velonote.studio.models.EraserMode
import com.velonote.studio.models.PageTemplate
import com.velonote.studio.models.PlacedSticker
import com.velonote.studio.models.StrokePoint
import com.velonote.studio.models.StudioSettings
import com.velonote.studio.models.ToolSlot
import com.velonote.studio.models.TouchTelemetry
import java.io.File
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/**
 * High-performance interactive Planner & Note-Taking Canvas combining:
 * - Module 1: Advanced Touch & Palm Rejection Engine via [pointerInteropFilter]
 * - Module 2: Real-Time Quadratic Bézier + Catmull-Rom Smoothing, Highlighters with Darken/Multiply blending,
 *             and Dual Eraser Modes (Vector Stroke Eraser & BlendMode.Clear Pixel Eraser)
 * - Module 3: Dynamic Page Template Generator (Blank, Narrow/Wide Lined, Square/Isometric Grid, Dotted)
 *             and Standardized Aspect Ratios with pinch-to-zoom & two-finger panning
 * - Module 4: Interactive Placed Stickers with drag, resize, rotate, and delete handles
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun DrawingCanvasSurface(
    strokes: List<DrawnStroke>,
    placedStickers: List<PlacedSticker>,
    selectedStickerId: String?,
    activeToolCategory: ActiveToolCategory,
    activeToolSlot: ToolSlot,
    eraserMode: EraserMode,
    eraserRadius: Float,
    settings: StudioSettings,
    viewportScale: Float,
    viewportOffset: Offset,
    onViewportChanged: (scale: Float, offset: Offset) -> Unit,
    onCommitStroke: (DrawnStroke) -> Unit,
    onDeleteStrokesByErase: (Set<String>) -> Unit,
    onLassoStrokesCaptured: (List<DrawnStroke>) -> Unit,
    onSelectSticker: (String?) -> Unit,
    onUpdateSticker: (PlacedSticker) -> Unit,
    onDeleteSticker: (String) -> Unit,
    onTelemetryUpdate: (TouchTelemetry) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current.density
    var containerSize by remember { mutableStateOf(IntSize.Zero) }

    // Live in-progress stroke points during an active pointer gesture
    var activeRawPoints by remember { mutableStateOf<List<StrokePoint>>(emptyList()) }
    var activeSmoothedPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var activePointerCanvasPos by remember { mutableStateOf<Offset?>(null) }
    var hardwareEraserOverride by remember { mutableStateOf(false) }

    // Cache decoded ImageBitmaps for placed stickers
    val stickerBitmapCache = remember { mutableStateMapOf<String, ImageBitmap>() }
    LaunchedEffect(placedStickers) {
        for (sticker in placedStickers) {
            if (!stickerBitmapCache.containsKey(sticker.filePath)) {
                val file = File(sticker.filePath)
                if (file.exists()) {
                    BitmapFactory.decodeFile(file.absolutePath)?.let { bmp ->
                        stickerBitmapCache[sticker.filePath] = bmp.asImageBitmap()
                    }
                }
            }
        }
    }

    val pageWidth = settings.aspectRatio.widthPx
    val pageHeight = settings.aspectRatio.heightPx

    // Center the page naturally inside the viewport when scale == 1f and offset == Zero
    val basePageTopLeft = remember(containerSize, pageWidth, pageHeight, viewportScale, viewportOffset) {
        val fitScale = if (containerSize.width > 0 && containerSize.height > 0) {
            min(
                (containerSize.width * 0.90f) / pageWidth,
                (containerSize.height * 0.84f) / pageHeight
            ).coerceIn(0.25f, 1.5f)
        } else {
            0.6f
        }
        val effectiveScale = fitScale * viewportScale
        val left = (containerSize.width - pageWidth * effectiveScale) * 0.5f + viewportOffset.x
        val top = (containerSize.height - pageHeight * effectiveScale) * 0.5f + viewportOffset.y
        Triple(left, top, effectiveScale)
    }

    val pageLeft = basePageTopLeft.first
    val pageTop = basePageTopLeft.second
    val effectiveScale = basePageTopLeft.third

    // Keep latest state references for the MotionEvent callback
    val currentStrokes by rememberUpdatedState(strokes)
    val currentSettings by rememberUpdatedState(settings)
    val currentToolCategory by rememberUpdatedState(activeToolCategory)
    val currentToolSlot by rememberUpdatedState(activeToolSlot)
    val currentEraserMode by rememberUpdatedState(eraserMode)
    val currentEraserRadius by rememberUpdatedState(eraserRadius)
    val currentViewportScale by rememberUpdatedState(viewportScale)
    val currentViewportOffset by rememberUpdatedState(viewportOffset)
    val currentEffectiveScale by rememberUpdatedState(effectiveScale)
    val currentPageLeft by rememberUpdatedState(pageLeft)
    val currentPageTop by rememberUpdatedState(pageTop)

    val screenToPage: (Offset) -> Offset = { screenPt ->
        Offset(
            x = (screenPt.x - currentPageLeft) / currentEffectiveScale,
            y = (screenPt.y - currentPageTop) / currentEffectiveScale
        )
    }

    val touchEngine = remember {
        TouchPalmRejectionEngine(
            object : CanvasTouchListener {
                override fun onStrokeBegin(canvasPoint: StrokePoint, isHardwareStylusEraser: Boolean) {
                    onSelectSticker(null)
                    hardwareEraserOverride = isHardwareStylusEraser
                    val effectiveCategory = if (isHardwareStylusEraser) {
                        ActiveToolCategory.ERASER
                    } else {
                        currentToolCategory
                    }

                    if (effectiveCategory == ActiveToolCategory.PAN_ZOOM) {
                        return
                    }

                    activeRawPoints = listOf(canvasPoint)
                    val pt = Offset(canvasPoint.x, canvasPoint.y)
                    activeSmoothedPoints = listOf(pt)
                    activePointerCanvasPos = pt

                    if (effectiveCategory == ActiveToolCategory.ERASER &&
                        currentEraserMode == EraserMode.STROKE
                    ) {
                        performVectorStrokeEraseAt(pt, currentEraserRadius, currentStrokes, onDeleteStrokesByErase)
                    }
                }

                override fun onStrokeMove(canvasPoints: List<StrokePoint>) {
                    val effectiveCategory = if (hardwareEraserOverride) {
                        ActiveToolCategory.ERASER
                    } else {
                        currentToolCategory
                    }

                    if (effectiveCategory == ActiveToolCategory.PAN_ZOOM) {
                        // In single-finger pan mode, translate the viewport
                        if (canvasPoints.isNotEmpty() && activePointerCanvasPos != null) {
                            val latest = canvasPoints.last()
                            val dx = (latest.x - activePointerCanvasPos!!.x) * currentEffectiveScale
                            val dy = (latest.y - activePointerCanvasPos!!.y) * currentEffectiveScale
                            onViewportChanged(
                                currentViewportScale,
                                Offset(currentViewportOffset.x + dx, currentViewportOffset.y + dy)
                            )
                        }
                        return
                    }

                    if (activeRawPoints.isEmpty()) return

                    val updatedRaw = activeRawPoints + canvasPoints
                    activeRawPoints = updatedRaw
                    activePointerCanvasPos = Offset(canvasPoints.last().x, canvasPoints.last().y)

                    if (effectiveCategory == ActiveToolCategory.ERASER &&
                        currentEraserMode == EraserMode.STROKE
                    ) {
                        for (pt in canvasPoints) {
                            performVectorStrokeEraseAt(
                                Offset(pt.x, pt.y),
                                currentEraserRadius,
                                currentStrokes,
                                onDeleteStrokesByErase
                            )
                        }
                        activeSmoothedPoints = updatedRaw.takeLast(12).map { Offset(it.x, it.y) }
                    } else {
                        val smoothing = if (effectiveCategory == ActiveToolCategory.LASSO) {
                            0.35f
                        } else {
                            currentSettings.smoothingIntensity
                        }
                        activeSmoothedPoints = StrokeSmoothingAndGeometry.computeSmoothedPoints(
                            rawPoints = updatedRaw,
                            smoothingIntensity = smoothing
                        )
                    }
                }

                override fun onStrokeEnd() {
                    val effectiveCategory = if (hardwareEraserOverride) {
                        ActiveToolCategory.ERASER
                    } else {
                        currentToolCategory
                    }

                    val raw = activeRawPoints
                    val smoothed = activeSmoothedPoints

                    if (raw.isNotEmpty() && smoothed.isNotEmpty()) {
                        when (effectiveCategory) {
                            ActiveToolCategory.PEN, ActiveToolCategory.HIGHLIGHTER -> {
                                val isHighlighter = (effectiveCategory == ActiveToolCategory.HIGHLIGHTER)
                                val bounds = StrokeSmoothingAndGeometry.computeBoundingBox(
                                    points = smoothed,
                                    strokeWidth = currentToolSlot.strokeWidth
                                )
                                onCommitStroke(
                                    DrawnStroke(
                                        rawPoints = raw,
                                        smoothedPoints = smoothed,
                                        colorHex = currentToolSlot.colorHex,
                                        opacity = currentToolSlot.opacity,
                                        strokeWidth = currentToolSlot.strokeWidth,
                                        isHighlighter = isHighlighter,
                                        isPixelEraserMask = false,
                                        boundingBox = bounds
                                    )
                                )
                            }

                            ActiveToolCategory.ERASER -> {
                                if (currentEraserMode == EraserMode.PIXEL) {
                                    val diameter = currentEraserRadius * 2f
                                    val bounds = StrokeSmoothingAndGeometry.computeBoundingBox(
                                        points = smoothed,
                                        strokeWidth = diameter
                                    )
                                    onCommitStroke(
                                        DrawnStroke(
                                            rawPoints = raw,
                                            smoothedPoints = smoothed,
                                            colorHex = "#000000",
                                            opacity = 1f,
                                            strokeWidth = diameter,
                                            isHighlighter = false,
                                            isPixelEraserMask = true,
                                            boundingBox = bounds
                                        )
                                    )
                                }
                            }

                            ActiveToolCategory.LASSO -> {
                                if (smoothed.size >= 3) {
                                    val captured = currentStrokes.filter { stroke ->
                                        StrokeSmoothingAndGeometry.isStrokeSelectedByLasso(stroke, smoothed)
                                    }
                                    if (captured.isNotEmpty()) {
                                        onLassoStrokesCaptured(captured)
                                    }
                                }
                            }

                            ActiveToolCategory.PAN_ZOOM -> Unit
                        }
                    }

                    activeRawPoints = emptyList()
                    activeSmoothedPoints = emptyList()
                    activePointerCanvasPos = null
                    hardwareEraserOverride = false
                }

                override fun onStrokeCancel(reason: String) {
                    activeRawPoints = emptyList()
                    activeSmoothedPoints = emptyList()
                    activePointerCanvasPos = null
                    hardwareEraserOverride = false
                }

                override fun onCanvasPanZoom(panDeltaScreen: Offset, zoomFactor: Float, pivotScreen: Offset) {
                    val newScale = (currentViewportScale * zoomFactor).coerceIn(0.45f, 4.5f)
                    val scaleRatio = newScale / currentViewportScale

                    // Zoom around finger centroid while applying pan translation
                    val centerScreen = Offset(containerSize.width * 0.5f, containerSize.height * 0.5f)
                    val pivotRelative = pivotScreen - centerScreen - currentViewportOffset
                    val zoomedOffset = currentViewportOffset - pivotRelative * (scaleRatio - 1f) + panDeltaScreen

                    onViewportChanged(newScale, zoomedOffset)
                }

                override fun onTelemetryUpdated(telemetry: TouchTelemetry) {
                    onTelemetryUpdate(telemetry)
                }
            }
        )
    }

    val workspaceBg = Color(settings.canvasTheme.workspaceBgHex)
    val paperBg = Color(settings.canvasTheme.paperBgHex)
    val templateLineColor = Color(settings.canvasTheme.lineColorHex)
    val isDarkCanvas = settings.canvasTheme == CanvasThemeMode.OBSIDIAN_DARK

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(workspaceBg)
            .onSizeChanged { containerSize = it }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                // Offscreen compositing enables BlendMode.Clear (Pixel Eraser) and Highlighter Multiply/Darken
                .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                .pointerInteropFilter { motionEvent ->
                    touchEngine.processMotionEvent(
                        event = motionEvent,
                        settings = currentSettings,
                        screenDensity = density,
                        screenToCanvasTransform = screenToPage
                    )
                }
        ) {
            withTransform({
                translate(left = pageLeft, top = pageTop)
                scale(scaleX = effectiveScale, scaleY = effectiveScale, pivot = Offset.Zero)
            }) {
                // 1. Subtle Elevation Shadow under Paper Sheet
                drawRoundRect(
                    color = Color.Black.copy(alpha = if (isDarkCanvas) 0.45f else 0.12f),
                    topLeft = Offset(10f, 16f),
                    size = Size(pageWidth, pageHeight),
                    cornerRadius = CornerRadius(12f, 12f)
                )

                // 2. Paper Surface & Clipped Page Content
                clipRect(left = 0f, top = 0f, right = pageWidth, bottom = pageHeight) {
                    drawRect(
                        color = paperBg,
                        topLeft = Offset.Zero,
                        size = Size(pageWidth, pageHeight)
                    )

                    // 3. Dynamic Page Template Generator (Blank, Lined, Grid, Isometric, Dotted)
                    drawPageTemplatePattern(
                        template = settings.pageTemplate,
                        pageWidth = pageWidth,
                        pageHeight = pageHeight,
                        lineColor = templateLineColor,
                        isDarkCanvas = isDarkCanvas
                    )

                    // 4. Isolated Offscreen Ink & Highlighter Layer so BlendMode.Clear only erases ink
                    //    (never erasing the underlying page paper or template lines!)
                    drawIntoCanvas { canvas ->
                        val layerBounds = Rect(0f, 0f, pageWidth, pageHeight)
                        canvas.saveLayer(layerBounds, Paint())

                        val highlighterBlend = if (isDarkCanvas) BlendMode.Screen else BlendMode.Darken

                        // Pass 4A: Render Highlighters beneath opaque pen strokes so black text stays crisp
                        for (stroke in strokes) {
                            if (stroke.isHighlighter && !stroke.isPixelEraserMask) {
                                val path = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(stroke.smoothedPoints)
                                drawPath(
                                    path = path,
                                    color = stroke.renderColor,
                                    style = Stroke(
                                        width = stroke.strokeWidth,
                                        cap = StrokeCap.Square,
                                        join = StrokeJoin.Round
                                    ),
                                    blendMode = highlighterBlend
                                )
                            }
                        }

                        // Pass 4B: Render Pen Strokes & Pixel Eraser Masks in chronological order
                        for (stroke in strokes) {
                            if (stroke.isPixelEraserMask) {
                                val maskPath = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(stroke.smoothedPoints)
                                drawPath(
                                    path = maskPath,
                                    color = Color.Transparent,
                                    style = Stroke(
                                        width = stroke.strokeWidth,
                                        cap = StrokeCap.Round,
                                        join = StrokeJoin.Round
                                    ),
                                    blendMode = BlendMode.Clear
                                )
                            } else if (!stroke.isHighlighter) {
                                val inkPath = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(stroke.smoothedPoints)
                                drawPath(
                                    path = inkPath,
                                    color = stroke.renderColor,
                                    style = Stroke(
                                        width = stroke.strokeWidth,
                                        cap = StrokeCap.Round,
                                        join = StrokeJoin.Round
                                    )
                                )
                            }
                        }

                        // Pass 4C: Render Live In-Progress Stroke or Pixel Eraser Preview
                        val effectiveCategory = if (hardwareEraserOverride) {
                            ActiveToolCategory.ERASER
                        } else {
                            activeToolCategory
                        }

                        if (activeSmoothedPoints.isNotEmpty()) {
                            when (effectiveCategory) {
                                ActiveToolCategory.PEN -> {
                                    val livePath = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(activeSmoothedPoints)
                                    drawPath(
                                        path = livePath,
                                        color = activeToolSlot.composeColor,
                                        style = Stroke(
                                            width = activeToolSlot.strokeWidth,
                                            cap = StrokeCap.Round,
                                            join = StrokeJoin.Round
                                        )
                                    )
                                }

                                ActiveToolCategory.HIGHLIGHTER -> {
                                    val livePath = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(activeSmoothedPoints)
                                    drawPath(
                                        path = livePath,
                                        color = activeToolSlot.composeColor,
                                        style = Stroke(
                                            width = activeToolSlot.strokeWidth,
                                            cap = StrokeCap.Square,
                                            join = StrokeJoin.Round
                                        ),
                                        blendMode = highlighterBlend
                                    )
                                }

                                ActiveToolCategory.ERASER -> {
                                    if (eraserMode == EraserMode.PIXEL) {
                                        val liveMask = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(activeSmoothedPoints)
                                        drawPath(
                                            path = liveMask,
                                            color = Color.Transparent,
                                            style = Stroke(
                                                width = eraserRadius * 2f,
                                                cap = StrokeCap.Round,
                                                join = StrokeJoin.Round
                                            ),
                                            blendMode = BlendMode.Clear
                                        )
                                    }
                                }

                                ActiveToolCategory.LASSO -> {
                                    val lassoPath = StrokeSmoothingAndGeometry.buildQuadraticBezierPath(activeSmoothedPoints)
                                    drawPath(
                                        path = lassoPath,
                                        color = Color(0xFF5C6BC0),
                                        style = Stroke(
                                            width = 3.5f,
                                            cap = StrokeCap.Round,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
                                        )
                                    )
                                }

                                ActiveToolCategory.PAN_ZOOM -> Unit
                            }
                        }

                        canvas.restore()
                    }

                    // 5. Render Placed Stickers on the Page Canvas
                    for (sticker in placedStickers) {
                        val bmp = stickerBitmapCache[sticker.filePath]
                        if (bmp != null) {
                            withTransform({
                                rotate(
                                    degrees = sticker.rotationDegrees,
                                    pivot = Offset(sticker.centerX, sticker.centerY)
                                )
                            }) {
                                val dstTopLeft = IntOffset(
                                    (sticker.centerX - sticker.width * 0.5f).roundToInt(),
                                    (sticker.centerY - sticker.height * 0.5f).roundToInt()
                                )
                                val dstSize = IntSize(
                                    sticker.width.roundToInt().coerceAtLeast(24),
                                    sticker.height.roundToInt().coerceAtLeast(24)
                                )
                                drawImage(
                                    image = bmp,
                                    dstOffset = dstTopLeft,
                                    dstSize = dstSize
                                )

                                if (selectedStickerId == sticker.instanceId) {
                                    drawRect(
                                        color = Color(0xFF4A6FA5),
                                        topLeft = Offset(
                                            sticker.centerX - sticker.width * 0.5f,
                                            sticker.centerY - sticker.height * 0.5f
                                        ),
                                        size = Size(sticker.width, sticker.height),
                                        style = Stroke(
                                            width = 2.5f,
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // 6. Draw Live Eraser Cursor Ring when Erasing
                    val cursorPos = activePointerCanvasPos
                    if (cursorPos != null && (activeToolCategory == ActiveToolCategory.ERASER || hardwareEraserOverride)) {
                        drawCircle(
                            color = if (eraserMode == EraserMode.STROKE) Color(0xFFE57373) else Color(0xFF64B5F6),
                            radius = eraserRadius,
                            center = cursorPos,
                            style = Stroke(width = 2.2f)
                        )
                    }
                }
            }
        }

        // 7. Interactive Sticker Transform Handles (Move, Resize, Rotate, Delete)
        for (sticker in placedStickers) {
            val screenCenterX = pageLeft + sticker.centerX * effectiveScale
            val screenCenterY = pageTop + sticker.centerY * effectiveScale
            val screenW = sticker.width * effectiveScale
            val screenH = sticker.height * effectiveScale
            val isSelected = (selectedStickerId == sticker.instanceId)

            StickerInteractiveOverlay(
                sticker = sticker,
                isSelected = isSelected,
                screenCenterX = screenCenterX,
                screenCenterY = screenCenterY,
                screenWidthPx = screenW,
                screenHeightPx = screenH,
                effectiveScale = effectiveScale,
                onSelect = { onSelectSticker(sticker.instanceId) },
                onUpdate = onUpdateSticker,
                onDelete = { onDeleteSticker(sticker.instanceId) }
            )
        }
    }
}

@Composable
private fun StickerInteractiveOverlay(
    sticker: PlacedSticker,
    isSelected: Boolean,
    screenCenterX: Float,
    screenCenterY: Float,
    screenWidthPx: Float,
    screenHeightPx: Float,
    effectiveScale: Float,
    onSelect: () -> Unit,
    onUpdate: (PlacedSticker) -> Unit,
    onDelete: () -> Unit
) {
    val density = LocalDensity.current
    val currentSticker by rememberUpdatedState(sticker)
    val currentScale by rememberUpdatedState(effectiveScale)

    // Invisible tap/drag body box over the sticker
    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    (screenCenterX - screenWidthPx * 0.5f).roundToInt(),
                    (screenCenterY - screenHeightPx * 0.5f).roundToInt()
                )
            }
            .size(
                width = with(density) { screenWidthPx.toDp() },
                height = with(density) { screenHeightPx.toDp() }
            )
            .pointerInput(sticker.instanceId) {
                detectDragGestures(
                    onDragStart = { onSelect() },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val updated = currentSticker.copy(
                            centerX = currentSticker.centerX + dragAmount.x / currentScale,
                            centerY = currentSticker.centerY + dragAmount.y / currentScale
                        )
                        onUpdate(updated)
                    }
                )
            }
    )

    if (isSelected) {
        // Top-Left Delete Handle
        Surface(
            shape = CircleShape,
            color = Color(0xFFD9534F),
            shadowElevation = 4.dp,
            modifier = Modifier
                .offset {
                    IntOffset(
                        (screenCenterX - screenWidthPx * 0.5f - 18f).roundToInt(),
                        (screenCenterY - screenHeightPx * 0.5f - 18f).roundToInt()
                    )
                }
                .size(28.dp)
        ) {
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Remove Sticker",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Bottom-Right Resize Handle
        Surface(
            shape = CircleShape,
            color = Color(0xFF3E5C76),
            shadowElevation = 4.dp,
            modifier = Modifier
                .offset {
                    IntOffset(
                        (screenCenterX + screenWidthPx * 0.5f - 14f).roundToInt(),
                        (screenCenterY + screenHeightPx * 0.5f - 14f).roundToInt()
                    )
                }
                .size(28.dp)
                .pointerInput(sticker.instanceId) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val deltaPageX = dragAmount.x / currentScale
                        val deltaPageY = dragAmount.y / currentScale
                        val updated = currentSticker.copy(
                            width = (currentSticker.width + deltaPageX * 2f).coerceIn(80f, 1200f),
                            height = (currentSticker.height + deltaPageY * 2f).coerceIn(80f, 1200f)
                        )
                        onUpdate(updated)
                    }
                }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Outlined.OpenWith,
                    contentDescription = "Resize Sticker",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        }

        // Top-Right Rotate Handle
        Surface(
            shape = CircleShape,
            color = Color(0xFF5E7CE2),
            shadowElevation = 4.dp,
            modifier = Modifier
                .offset {
                    IntOffset(
                        (screenCenterX + screenWidthPx * 0.5f - 14f).roundToInt(),
                        (screenCenterY - screenHeightPx * 0.5f - 18f).roundToInt()
                    )
                }
                .size(28.dp)
                .pointerInput(sticker.instanceId) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val angleDelta = (dragAmount.x + dragAmount.y) * 0.45f
                        val updated = currentSticker.copy(
                            rotationDegrees = (currentSticker.rotationDegrees + angleDelta) % 360f
                        )
                        onUpdate(updated)
                    }
                }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Outlined.RotateRight,
                    contentDescription = "Rotate Sticker",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

private fun performVectorStrokeEraseAt(
    eraserPoint: Offset,
    eraserRadius: Float,
    strokes: List<DrawnStroke>,
    onDeleteStrokes: (Set<String>) -> Unit
) {
    val hitIds = mutableSetOf<String>()
    for (stroke in strokes) {
        if (!stroke.isPixelEraserMask &&
            StrokeSmoothingAndGeometry.doesEraserIntersectStroke(eraserPoint, eraserRadius, stroke)
        ) {
            hitIds.add(stroke.id)
        }
    }
    if (hitIds.isNotEmpty()) {
        onDeleteStrokes(hitIds)
    }
}

// ===========================================================================
// MODULE 3: DYNAMIC PAGE TEMPLATE GENERATOR
// ===========================================================================

private fun DrawScope.drawPageTemplatePattern(
    template: PageTemplate,
    pageWidth: Float,
    pageHeight: Float,
    lineColor: Color,
    isDarkCanvas: Boolean
) {
    val headerMargin = 110f
    val marginAccent = if (isDarkCanvas) {
        Color(0xFF8C4A52).copy(alpha = 0.45f)
    } else {
        Color(0xFFE29587).copy(alpha = 0.55f)
    }

    when (template) {
        PageTemplate.BLANK -> Unit

        PageTemplate.LINED_NARROW -> {
            val spacing = 38f
            var y = headerMargin
            while (y < pageHeight - 48f) {
                drawLine(
                    color = lineColor,
                    start = Offset(0f, y),
                    end = Offset(pageWidth, y),
                    strokeWidth = 1.4f
                )
                y += spacing
            }
            // Classic vertical margin line
            drawLine(
                color = marginAccent,
                start = Offset(135f, 0f),
                end = Offset(135f, pageHeight),
                strokeWidth = 1.8f
            )
        }

        PageTemplate.LINED_WIDE -> {
            val spacing = 58f
            var y = headerMargin
            while (y < pageHeight - 48f) {
                drawLine(
                    color = lineColor,
                    start = Offset(0f, y),
                    end = Offset(pageWidth, y),
                    strokeWidth = 1.6f
                )
                y += spacing
            }
            drawLine(
                color = marginAccent,
                start = Offset(150f, 0f),
                end = Offset(150f, pageHeight),
                strokeWidth = 2.0f
            )
        }

        PageTemplate.GRID_SQUARE -> {
            val cell = 44f
            var x = cell
            var colIndex = 1
            while (x < pageWidth) {
                val isMajor = (colIndex % 5 == 0)
                drawLine(
                    color = if (isMajor) lineColor.copy(alpha = 0.95f) else lineColor.copy(alpha = 0.55f),
                    start = Offset(x, 0f),
                    end = Offset(x, pageHeight),
                    strokeWidth = if (isMajor) 1.8f else 1.1f
                )
                x += cell
                colIndex++
            }

            var y = cell
            var rowIndex = 1
            while (y < pageHeight) {
                val isMajor = (rowIndex % 5 == 0)
                drawLine(
                    color = if (isMajor) lineColor.copy(alpha = 0.95f) else lineColor.copy(alpha = 0.55f),
                    start = Offset(0f, y),
                    end = Offset(pageWidth, y),
                    strokeWidth = if (isMajor) 1.8f else 1.1f
                )
                y += cell
                rowIndex++
            }
        }

        PageTemplate.GRID_ISOMETRIC -> {
            val spacing = 56f
            val tan30 = tan(PI / 6.0).toFloat()
            val dyFullWidth = pageWidth * tan30

            // Vertical columns
            val colStep = spacing * cos(PI / 6.0).toFloat()
            var x = colStep
            while (x < pageWidth) {
                drawLine(
                    color = lineColor.copy(alpha = 0.45f),
                    start = Offset(x, 0f),
                    end = Offset(x, pageHeight),
                    strokeWidth = 1.1f
                )
                x += colStep
            }

            // +30 degree and -30 degree isometric axes
            var startY = -dyFullWidth
            while (startY < pageHeight + dyFullWidth) {
                drawLine(
                    color = lineColor.copy(alpha = 0.72f),
                    start = Offset(0f, startY),
                    end = Offset(pageWidth, startY + dyFullWidth),
                    strokeWidth = 1.25f
                )
                drawLine(
                    color = lineColor.copy(alpha = 0.72f),
                    start = Offset(0f, startY + dyFullWidth),
                    end = Offset(pageWidth, startY),
                    strokeWidth = 1.25f
                )
                startY += spacing
            }
        }

        PageTemplate.DOTTED -> {
            val dotSpacing = 42f
            val dotRadius = 2.4f
            var y = dotSpacing
            while (y < pageHeight - 24f) {
                var x = dotSpacing
                while (x < pageWidth - 24f) {
                    drawCircle(
                        color = lineColor,
                        radius = dotRadius,
                        center = Offset(x, y)
                    )
                    x += dotSpacing
                }
                y += dotSpacing
            }
        }
    }
}