package com.velonote.studio.ui

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.AutoFixNormal
import androidx.compose.material.icons.outlined.BorderColor
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.UnfoldLess
import androidx.compose.material.icons.outlined.UnfoldMore
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.velonote.studio.canvas.DrawingCanvasSurface
import com.velonote.studio.models.ActiveToolCategory
import com.velonote.studio.models.CanvasThemeMode
import com.velonote.studio.models.DrawnStroke
import com.velonote.studio.models.EraserMode
import com.velonote.studio.models.PageAspectRatio
import com.velonote.studio.models.PageTemplate
import com.velonote.studio.models.PlacedSticker
import com.velonote.studio.models.StickerBitmapProcessor
import com.velonote.studio.models.StickerDao
import com.velonote.studio.models.StickerEntity
import com.velonote.studio.models.StudioSettings
import com.velonote.studio.models.ToolSlot
import com.velonote.studio.models.ToolbarHandedness
import com.velonote.studio.models.TouchTelemetry
import com.velonote.studio.settings.StudioSettingsBottomSheet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/**
 * Main Chic Minimalist Planner & Note-Taking Workspace (Penly-inspired UI).
 */
@Composable
fun VeloNoteStudioScreen(
    stickerDao: StickerDao
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val savedStickers by stickerDao.observeAllStickers().collectAsState(initial = emptyList())

    // Studio & Palm-Rejection Configuration State
    var settings by remember { mutableStateOf(StudioSettings()) }
    var telemetry by remember { mutableStateOf(TouchTelemetry()) }

    // Saved Pen & Highlighter Dock Slots
    val toolSlots = remember {
        mutableStateListOf(
            ToolSlot(
                id = "pen_1",
                category = ActiveToolCategory.PEN,
                label = "Fountain Ink",
                colorHex = "#232629",
                strokeWidth = 4.2f,
                opacity = 1.0f
            ),
            ToolSlot(
                id = "pen_2",
                category = ActiveToolCategory.PEN,
                label = "Cobalt Gel",
                colorHex = "#3D5A80",
                strokeWidth = 3.6f,
                opacity = 1.0f
            ),
            ToolSlot(
                id = "pen_3",
                category = ActiveToolCategory.PEN,
                label = "Terracotta Fine",
                colorHex = "#A24936",
                strokeWidth = 3.2f,
                opacity = 1.0f
            ),
            ToolSlot(
                id = "hl_1",
                category = ActiveToolCategory.HIGHLIGHTER,
                label = "Warm Honey Chisel",
                colorHex = "#F2CC8F",
                strokeWidth = 26f,
                opacity = 0.45f
            ),
            ToolSlot(
                id = "hl_2",
                category = ActiveToolCategory.HIGHLIGHTER,
                label = "Sage Matcha Chisel",
                colorHex = "#81B29A",
                strokeWidth = 28f,
                opacity = 0.42f
            ),
            ToolSlot(
                id = "hl_3",
                category = ActiveToolCategory.HIGHLIGHTER,
                label = "Lavender Mist",
                colorHex = "#CDB4DB",
                strokeWidth = 26f,
                opacity = 0.45f
            )
        )
    }

    var activeToolCategory by remember { mutableStateOf(ActiveToolCategory.PEN) }
    var activeSlotId by remember { mutableStateOf("pen_1") }
    val activeSlot = toolSlots.firstOrNull { it.id == activeSlotId } ?: toolSlots.first()

    // Dual Eraser State
    var eraserMode by remember { mutableStateOf(EraserMode.STROKE) }
    var eraserRadius by remember { mutableFloatStateOf(22f) }
    var showEraserPopover by remember { mutableStateOf(false) }

    // Canvas Strokes + Undo/Redo History Stacks
    val strokes = remember { mutableStateListOf<DrawnStroke>() }
    val undoStack = remember { mutableStateListOf<List<DrawnStroke>>() }
    val redoStack = remember { mutableStateListOf<List<DrawnStroke>>() }

    // Placed Stickers on Active Page
    val placedStickers = remember { mutableStateListOf<PlacedSticker>() }
    var selectedStickerId by remember { mutableStateOf<String?>(null) }

    // Viewport Zoom & Pan State
    var viewportScale by remember { mutableFloatStateOf(1.0f) }
    var viewportOffset by remember { mutableStateOf(Offset.Zero) }

    // Dialog & Sheet Visibility State
    var isToolbarCollapsed by remember { mutableStateOf(false) }
    var editingSlotInColorDialog by remember { mutableStateOf<ToolSlot?>(null) }
    var showStickerStudioSheet by remember { mutableStateOf(false) }
    var pendingLassoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showTemplateQuickBar by remember { mutableStateOf(false) }

    fun pushUndoSnapshot() {
        undoStack.add(strokes.toList())
        if (undoStack.size > 40) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    val isDarkChrome = settings.canvasTheme == CanvasThemeMode.OBSIDIAN_DARK
    val pillSurfaceColor = if (isDarkChrome) {
        Color(0xFF25282E).copy(alpha = 0.92f)
    } else {
        Color(0xFFFDFBF7).copy(alpha = 0.94f)
    }
    val pillBorderColor = if (isDarkChrome) {
        Color(0xFF3B3F47)
    } else {
        Color(0xFFE4DEC3)
    }
    val primaryTextColor = if (isDarkChrome) Color(0xFFF2EFE9) else Color(0xFF232629)

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Main Interactive Drawing & Planner Canvas
        DrawingCanvasSurface(
            strokes = strokes,
            placedStickers = placedStickers,
            selectedStickerId = selectedStickerId,
            activeToolCategory = activeToolCategory,
            activeToolSlot = activeSlot,
            eraserMode = eraserMode,
            eraserRadius = eraserRadius,
            settings = settings,
            viewportScale = viewportScale,
            viewportOffset = viewportOffset,
            onViewportChanged = { newScale, newOffset ->
                viewportScale = newScale
                viewportOffset = newOffset
            },
            onCommitStroke = { newStroke ->
                pushUndoSnapshot()
                strokes.add(newStroke)
            },
            onDeleteStrokesByErase = { idsToDelete ->
                if (idsToDelete.isNotEmpty()) {
                    pushUndoSnapshot()
                    strokes.removeAll { it.id in idsToDelete }
                }
            },
            onLassoStrokesCaptured = { capturedStrokes ->
                val bmp = StickerBitmapProcessor.rasterizeLassoStrokesToBitmap(capturedStrokes)
                if (bmp != null) {
                    pendingLassoBitmap = bmp
                    showStickerStudioSheet = true
                }
            },
            onSelectSticker = { selectedStickerId = it },
            onUpdateSticker = { updated ->
                val idx = placedStickers.indexOfFirst { it.instanceId == updated.instanceId }
                if (idx != -1) {
                    placedStickers[idx] = updated
                }
            },
            onDeleteSticker = { instanceId ->
                placedStickers.removeAll { it.instanceId == instanceId }
                if (selectedStickerId == instanceId) {
                    selectedStickerId = null
                }
            },
            onTelemetryUpdate = { telemetry = it },
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top Floating Collapsible Pill Toolbar
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 18.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = pillSurfaceColor,
                shadowElevation = 10.dp,
                modifier = Modifier.border(1.dp, pillBorderColor, CircleShape)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Collapse / Expand Pill Button
                    IconButton(
                        onClick = { isToolbarCollapsed = !isToolbarCollapsed },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isToolbarCollapsed) {
                                Icons.Outlined.UnfoldMore
                            } else {
                                Icons.Outlined.UnfoldLess
                            },
                            contentDescription = "Toggle Minimalist Pill",
                            tint = primaryTextColor
                        )
                    }

                    AnimatedVisibility(visible = !isToolbarCollapsed) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Saved Pen & Highlighter Slots (tap to activate, tap active slot to open HSV Color Wheel)
                            toolSlots.forEach { slot ->
                                val isSelected = (activeSlotId == slot.id) &&
                                    (activeToolCategory == slot.category)
                                ToolSlotPillButton(
                                    slot = slot,
                                    isSelected = isSelected,
                                    onClick = {
                                        if (isSelected) {
                                            editingSlotInColorDialog = slot
                                        } else {
                                            activeSlotId = slot.id
                                            activeToolCategory = slot.category
                                            showEraserPopover = false
                                        }
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            // Dual Eraser Button
                            ToolIconCircleButton(
                                icon = Icons.Outlined.CleaningServices,
                                label = "Eraser",
                                isSelected = (activeToolCategory == ActiveToolCategory.ERASER),
                                tint = primaryTextColor,
                                onClick = {
                                    if (activeToolCategory == ActiveToolCategory.ERASER) {
                                        showEraserPopover = !showEraserPopover
                                    } else {
                                        activeToolCategory = ActiveToolCategory.ERASER
                                        showEraserPopover = true
                                    }
                                }
                            )

                            // Lasso-to-Sticker Selection Tool
                            ToolIconCircleButton(
                                icon = Icons.Outlined.ContentCut,
                                label = "Lasso Sticker",
                                isSelected = (activeToolCategory == ActiveToolCategory.LASSO),
                                tint = primaryTextColor,
                                onClick = {
                                    activeToolCategory = ActiveToolCategory.LASSO
                                    showEraserPopover = false
                                }
                            )

                            // Pan / Zoom Hand Mode
                            ToolIconCircleButton(
                                icon = Icons.Outlined.PanTool,
                                label = "Pan Canvas",
                                isSelected = (activeToolCategory == ActiveToolCategory.PAN_ZOOM),
                                tint = primaryTextColor,
                                onClick = {
                                    activeToolCategory = ActiveToolCategory.PAN_ZOOM
                                    showEraserPopover = false
                                }
                            )

                            // Undo Button
                            IconButton(
                                onClick = {
                                    if (undoStack.isNotEmpty()) {
                                        redoStack.add(strokes.toList())
                                        val prev = undoStack.removeAt(undoStack.lastIndex)
                                        strokes.clear()
                                        strokes.addAll(prev)
                                    }
                                },
                                enabled = undoStack.isNotEmpty(),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Undo,
                                    contentDescription = "Undo",
                                    tint = if (undoStack.isNotEmpty()) primaryTextColor else primaryTextColor.copy(alpha = 0.3f)
                                )
                            }

                            // Redo Button
                            IconButton(
                                onClick = {
                                    if (redoStack.isNotEmpty()) {
                                        undoStack.add(strokes.toList())
                                        val next = redoStack.removeAt(redoStack.lastIndex)
                                        strokes.clear()
                                        strokes.addAll(next)
                                    }
                                },
                                enabled = redoStack.isNotEmpty(),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Redo,
                                    contentDescription = "Redo",
                                    tint = if (redoStack.isNotEmpty()) primaryTextColor else primaryTextColor.copy(alpha = 0.3f)
                                )
                            }

                            // Sticker Studio Drawer Trigger
                            ToolIconCircleButton(
                                icon = Icons.Outlined.EmojiEmotions,
                                label = "Sticker Studio",
                                isSelected = showStickerStudioSheet,
                                tint = primaryTextColor,
                                onClick = { showStickerStudioSheet = true }
                            )

                            // Page Template & Ratio Quick Popover Trigger
                            ToolIconCircleButton(
                                icon = Icons.Outlined.GridOn,
                                label = "Page Template",
                                isSelected = showTemplateQuickBar,
                                tint = primaryTextColor,
                                onClick = {
                                    showTemplateQuickBar = !showTemplateQuickBar
                                    showEraserPopover = false
                                }
                            )

                            // Studio Settings Sheet Trigger
                            ToolIconCircleButton(
                                icon = Icons.Outlined.Settings,
                                label = "Settings",
                                isSelected = showSettingsSheet,
                                tint = primaryTextColor,
                                onClick = { showSettingsSheet = true }
                            )
                        }
                    }
                }
            }

            // Dual Eraser Mode Popover Card (Stroke Eraser vs. Pixel BlendMode.Clear Eraser)
            AnimatedVisibility(visible = showEraserPopover && activeToolCategory == ActiveToolCategory.ERASER) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = pillSurfaceColor,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .width(340.dp)
                        .border(1.dp, pillBorderColor, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EraserMode.entries.forEach { mode ->
                                FilterChip(
                                    selected = (eraserMode == mode),
                                    onClick = { eraserMode = mode },
                                    label = { Text(mode.title) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Text(
                            text = eraserMode.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = primaryTextColor.copy(alpha = 0.7f),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            Text(
                                text = "Radius: ${eraserRadius.roundToInt()}pt",
                                style = MaterialTheme.typography.labelSmall,
                                color = primaryTextColor
                            )
                            Slider(
                                value = eraserRadius,
                                onValueChange = { eraserRadius = it },
                                valueRange = 8f..64f,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    if (strokes.isNotEmpty()) {
                                        pushUndoSnapshot()
                                        strokes.clear()
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteSweep,
                                    contentDescription = "Clear All Strokes",
                                    tint = Color(0xFFD9534F)
                                )
                            }
                        }
                    }
                }
            }

            // Quick Page Template & Aspect Ratio Switcher Strip
            AnimatedVisibility(visible = showTemplateQuickBar) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = pillSurfaceColor,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .border(1.dp, pillBorderColor, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PageTemplate.entries.forEach { tpl ->
                                FilterChip(
                                    selected = (settings.pageTemplate == tpl),
                                    onClick = { settings = settings.copy(pageTemplate = tpl) },
                                    label = { Text(tpl.displayName, fontSize = 11.sp) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PageAspectRatio.entries.forEach { ratio ->
                                FilterChip(
                                    selected = (settings.aspectRatio == ratio),
                                    onClick = { settings = settings.copy(aspectRatio = ratio) },
                                    label = { Text(ratio.badge, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Adaptive Left-Handed / Right-Handed Side Quick Accessory Pill
        val sideAlignment = if (settings.handedness == ToolbarHandedness.LEFT_HANDED) {
            Alignment.CenterStart
        } else {
            Alignment.CenterEnd
        }

        Surface(
            shape = CircleShape,
            color = pillSurfaceColor,
            shadowElevation = 8.dp,
            modifier = Modifier
                .align(sideAlignment)
                .padding(horizontal = 14.dp)
                .border(1.dp, pillBorderColor, CircleShape)
        ) {
            Column(
                modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Open HSV Color & Width Picker for current Pen/Highlighter slot
                IconButton(
                    onClick = { editingSlotInColorDialog = activeSlot },
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(activeSlot.composeColor)
                            .border(2.dp, primaryTextColor, CircleShape)
                    )
                }

                // Quick Stroke Width Indicator Badge
                Text(
                    text = "${activeSlot.strokeWidth.roundToInt()}pt",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = primaryTextColor
                )

                // Reset Viewport Zoom & Pan Button
                IconButton(
                    onClick = {
                        viewportScale = 1.0f
                        viewportOffset = Offset.Zero
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CenterFocusStrong,
                        contentDescription = "Reset Page Zoom",
                        tint = primaryTextColor
                    )
                }
            }
        }

        // 4. Bottom Status Pill (Aspect Ratio, Zoom %, Palm Rejection Telemetry)
        Surface(
            shape = CircleShape,
            color = pillSurfaceColor,
            shadowElevation = 4.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 14.dp)
                .border(1.dp, pillBorderColor, CircleShape)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "${settings.aspectRatio.displayName} • ${settings.pageTemplate.displayName}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    color = primaryTextColor
                )
                Text(
                    text = "Zoom ${(viewportScale * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = primaryTextColor.copy(alpha = 0.75f)
                )
                Text(
                    text = "${telemetry.activeToolTypeLabel} (Palms Blocked: ${telemetry.palmRejectedCount})",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF4A6FA5)
                )
            }
        }
    }

    // HSV Color Wheel + Opacity + Hex Input Dialog
    editingSlotInColorDialog?.let { targetSlot ->
        HsvToolColorPickerDialog(
            slot = targetSlot,
            onDismiss = { editingSlotInColorDialog = null },
            onSaveSlot = { updatedSlot ->
                val idx = toolSlots.indexOfFirst { it.id == updatedSlot.id }
                if (idx != -1) {
                    toolSlots[idx] = updatedSlot
                }
                editingSlotInColorDialog = null
            }
        )
    }

    // Custom Sticker Studio Modal Bottom Sheet
    if (showStickerStudioSheet) {
        StickerStudioBottomSheet(
            savedStickers = savedStickers,
            pendingLassoBitmap = pendingLassoBitmap,
            onClearPendingLassoBitmap = { pendingLassoBitmap = null },
            onSaveNewSticker = { bmp, label, sourceType ->
                scope.launch(Dispatchers.IO) {
                    val savedFile = StickerBitmapProcessor.saveBitmapToStickerStorage(context, bmp)
                    val entity = StickerEntity(
                        name = label,
                        filePath = savedFile.absolutePath,
                        sourceType = sourceType
                    )
                    val newId = stickerDao.insertSticker(entity)
                    withContext(Dispatchers.Main) {
                        placedStickers.add(
                            PlacedSticker(
                                stickerEntityId = newId,
                                filePath = savedFile.absolutePath,
                                centerX = settings.aspectRatio.widthPx * 0.5f,
                                centerY = settings.aspectRatio.heightPx * 0.5f
                            )
                        )
                    }
                }
            },
            onPlaceStickerOnCanvas = { entity ->
                val newInstance = PlacedSticker(
                    stickerEntityId = entity.id,
                    filePath = entity.filePath,
                    centerX = settings.aspectRatio.widthPx * 0.5f,
                    centerY = settings.aspectRatio.heightPx * 0.5f
                )
                placedStickers.add(newInstance)
                selectedStickerId = newInstance.instanceId
            },
            onDeleteSavedSticker = { entity ->
                scope.launch(Dispatchers.IO) {
                    runCatching { File(entity.filePath).delete() }
                    stickerDao.deleteSticker(entity)
                }
            },
            onDismiss = { showStickerStudioSheet = false }
        )
    }

    // Comprehensive Studio Settings Modal Bottom Sheet
    if (showSettingsSheet) {
        StudioSettingsBottomSheet(
            settings = settings,
            telemetry = telemetry,
            onUpdateSettings = { settings = it },
            onDismiss = { showSettingsSheet = false }
        )
    }
}

@Composable
private fun ToolSlotPillButton(
    slot: ToolSlot,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val icon = if (slot.category == ActiveToolCategory.HIGHLIGHTER) {
        Icons.Outlined.BorderColor
    } else {
        Icons.Outlined.Create
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(
                if (isSelected) slot.composeColor.copy(alpha = 0.22f) else Color.Transparent
            )
            .border(
                width = if (isSelected) 2.2.dp else 1.dp,
                color = if (isSelected) slot.composeColor.copy(alpha = 1f) else Color.Transparent,
                shape = CircleShape
            )
            .clickable { onClick() }
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = slot.label,
                tint = slot.composeColor.copy(alpha = 1f),
                modifier = Modifier.size(18.dp)
            )
            Box(
                modifier = Modifier
                    .padding(top = 2.dp)
                    .width(14.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(slot.composeColor)
            )
        }
    }
}

@Composable
private fun ToolIconCircleButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    tint: Color,
    onClick: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isSelected) Color(0xFF4A6FA5).copy(alpha = 0.18f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) Color(0xFF4A6FA5) else Color.Transparent,
                shape = CircleShape
            )
            .clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) Color(0xFF4A6FA5) else tint,
            modifier = Modifier.size(19.dp)
        )
    }
}